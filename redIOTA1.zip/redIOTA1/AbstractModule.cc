//#define PY_SSIZE_T_CLEAN



#include "AbstractModule.h"

#include <iostream>
#include <string>

//Blockchain
#include <cstdint>
#include <vector>

#include <sstream>
#include "json.hpp"
#include "blockChain.h"
#include <fstream>
#include <cmath>
#include <math.h>

using std::string;

Tx* AbstractModule::createTx() 
{
    EV << "AbstractModule::createTx:txCount-> " << txCount << endl ;
    auto newTx = new Tx(ID + std::to_string(txCount));
    EV << "createTx: " << newTx->ID << "\n";
    newTx->issuedTime = simTime();
    txCount++;
    return newTx;
}

void AbstractModule::createGenBlock() 
{
    auto GenBlock = new Tx("Genesis");
    EV << "AbstractModule::CreateGenBlock-> " << GenBlock->ID << "\n";
    GenBlock->issuedTime = simTime();
    GenBlock->isGenesisBlock = true;

    myTangle.push_back(GenBlock);
    myTips.push_back(GenBlock);

}

int AbstractModule::getTxCount() const
{
    return txCount;
}

int AbstractModule::getTxLimit() const
{
    return txLimit;
}

void AbstractModule::setTxLimit(int newLimit)
{
    txLimit = newLimit;
}

void AbstractModule::printTangle() const
{
    std::fstream file;
    std::string path = "./data/tracking/Tangle" + ID + ".csv";
    remove(path.c_str());
    file.open(path,std::ios::app);

    for(auto const tx : myTangle)
    {
       file << tx->ID << ";";

        for(size_t j = 0; j < tx->approvedBy.size(); j++)
        {
            auto temp = tx->approvedBy[j];

            if(j == tx->approvedBy.size() - 1)
            {
                file << temp->ID;
            }

            else
            {
                file << temp->ID << ",";
            }
        }

        file << "\n";
    }

    file.close();
}

void AbstractModule::printTipsLeft(bool ifDeleteFile) const
{
    std::fstream file;
    std::string path = "./data/tracking/TipsNumber" + ID + ".csv";
    if(ifDeleteFile) remove(path.c_str());
    file.open(path,std::ios::app);
    file << myTips.size() << "\n";
    file.close();
}

void AbstractModule::printStats(bool ifDeleteFile) const
{

    std::fstream file;
    std::string path = "./data/tracking/Stats" + ID + ".csv";
    if(ifDeleteFile) remove(path.c_str());
    file.open(path,std::ios::app);
    file << "Nombre de la Red" << ";" << "N. de transacciones" << ";" << "Dimension del Tangle" << ";" << "N. de tips" << ";" << "Corriente Consumida" << ";" << "Peso Total" << ";\n";
    file << getParentModule()->getName() << ";" << txCount << ";" << myTangle.size() << ";" << myTips.size()  << ";" << currentTotal << ";" << peso << ";\n";
    file.close();

    // Guardar los registros de nodos asociados para cada nodo
    std::fstream file1;
    std::string path1 = "./data/tracking/tangleTable" + ID + ".csv";
    if(ifDeleteFile) remove(path1.c_str());
    file1.open(path1,std::ios::app);
    file1 << "Nodo" << ";" << ID << ";\n";

    for (auto master: tangleTable)
    {
        file1 << master << ";\n";
    }
    file1.close();

    // Guardar los registros de nodos marcados como atacantes para cada nodo
    std::fstream file2;
    std::string path2 = "./data/tracking/attackerTable" + ID + ".csv";
    if(ifDeleteFile) remove(path2.c_str());
    file2.open(path2,std::ios::app);
    file2 << "Nodo" << ";" << ID << ";\n";

    for (auto attPair: attackerNodes)
    {
        file2 << attPair << ";\n";
    }
    file2.close();

}

std::vector<std::tuple<Tx*,int,int>> AbstractModule::getSelectedTips(double alphaVal, int W, int N)
{
    std::vector<std::tuple<Tx*,int,int>> selectedTips;
    int walkTime;
    Tx* tip;

    for(int i = 0; i < N; i++)
    {
        int w = intuniform(W,2*W);
        Tx* startTx = getWalkStart(w);

        alphaVal ? tip = weightedRandomWalk(startTx,alphaVal,walkTime) : tip = randomWalk(startTx,walkTime);
        auto it = selectedTips.begin();

        for(; it != selectedTips.end(); it++)
        {
            if(std::get<0>(*it)->ID == tip->ID)
            {
                std::get<1>(*it)++;
                break;
            }
        }

        if(it == selectedTips.end() && isLegitTip(tip))
        {
            selectedTips.push_back(std::make_tuple(tip,1,walkTime));
        }
    }

    return selectedTips;
}

VpTx AbstractModule::IOTA(double alphaVal, int W, int N)
{
    if(myTips.size() == 1)
    {
        VpTx tipsToApprove;
        if(isLegitTip(myTips[0])) tipsToApprove.push_back(myTips[0]);
        return tipsToApprove;
    }

    std::vector<std::tuple<Tx*,int,int>> selectedTips;
    selectedTips = getSelectedTips(alphaVal,W,N);
    std::sort(selectedTips.begin(),selectedTips.end(),[](const std::tuple<Tx*,int,int>& tup1,const std::tuple<Tx*,int,int>& tup2){return std::get<1>(tup1) > std::get<1>(tup2);});

    if(selectedTips.size() == 1)
    {
        VpTx chosenTips = {std::get<0>(selectedTips[0])};
        return chosenTips;
    }

    VpTx chosenTips = {std::get<0>(selectedTips[0])};

    for(size_t i = 1; i < selectedTips.size(); i++)
    {
        auto tip = std::get<0>((selectedTips[i]));

        if(!ifConflictedTips(chosenTips[0],tip))
        {
            chosenTips.push_back(tip);
            break;
        }
    }

    return chosenTips;
}

VpTx AbstractModule::GIOTA(double alphaVal, int W, int N)
{
    for(auto tx : myTangle)
    {
        tx->confidence = 0.0;
        tx->countSelected = 0;
    }
    
    auto chosenTips = IOTA(alphaVal,W,N);

    if(chosenTips.size() == 1)
    {
        return chosenTips;
    }

    for(auto tip : myTips)
    {
        if(tip->countSelected && isLegitTip(tip))
        {
           for(auto tx : tip->approvedTx)
            {
               computeConfidence(tx,double(tip->countSelected/N));
            }
        }
    }

    std::vector<std::pair<double,Tx*>> avgConfTips;

    for(auto tip : myTips)
    {
        double avg = 0.0;

        for(auto tx : tip->approvedTx)
        {
            getAvgConf(tx,avg);
        }

        avgConfTips.push_back(std::make_pair(avg,tip));
    }

    std::sort(avgConfTips.begin(), avgConfTips.end(),[](const std::pair<double,Tx*> &tip1, const std::pair<double,Tx*> &tip2){return tip1.first < tip2.first;});

    for(auto pair : avgConfTips)
    {
        auto tip = pair.second;

        if(tip->ID != chosenTips[0]->ID && tip->ID != chosenTips[1]->ID)
        {
            if(!ifConflictedTips(chosenTips[0],tip) && !ifConflictedTips(chosenTips[1],tip))
            {
                chosenTips.push_back(tip);
                break;
            }
        }
    }

    return chosenTips;
}

VpTx AbstractModule::EIOTA(double p1, double p2, double lowAlpha, double highAlpha, int W, int N)
{
    auto r = uniform(0.0,1.0);

    if(r < p1)
    {
        return IOTA(0.0,W,N);
    }

    else if(p1 <= r && r < p2)
    {
       return IOTA(lowAlpha,W,N);
    }

    return IOTA(highAlpha,W,N);
}

VpTx AbstractModule::getTipsTSA()
{
    EV << "TSA procedure for the next transaction to be issued: " << ID + std::to_string(txCount) << "\n";

    //double WProp = par("WProp");
    int W = std::min(myTips.size(),(size_t) 100); //std::round(WProp * myTangle.size());

    if(strcmp(par("TSA"),"GIOTA") == 0)
    {
        return GIOTA(par("alpha"),W,par("N"));
    }

    else if(strcmp(par("TSA"),"EIOTA") == 0)
    {
        return EIOTA(par("p1"),par("p2"),par("lowAlpha"),par("highAlpha"),W,par("N"));
    }

    return IOTA(par("alpha"),W,par("N"));
}

Tx* AbstractModule::weightedRandomWalk(Tx* startTx, double alphaVal, int &walkTime)
{
    walkTime = 0;
    
    while(startTx->isApproved)
    {
        walkTime++;
        auto currentView = startTx->approvedBy;

        if(currentView.size() == 0)
        {
            break;
        }

        if(currentView.size() == 1)
        {
            startTx = currentView.front();
        }

        else
        {
            std::vector<int> txWeight;
            int startWeight;
            startWeight = computeWeight(startTx);
            //PESO
            EV << "*** Weight: " << std::to_string(startWeight) << "\n";
            std::vector<double> p;
            double sumExpo = 0.0;
            
            for(auto tx : currentView)
            {
                int weight;
                weight = computeWeight(tx); 
                sumExpo += double(exp(double(-alphaVal*(startWeight - weight))));
                txWeight.push_back(weight);
            }

            for(const auto weight : txWeight)
            {
               auto prob = double(exp(double(-alphaVal*(startWeight - weight))));
               prob = prob/sumExpo;
               p.push_back(prob);
            }

            auto p1 = p;
            std::rotate(p1.rbegin(), p1.rbegin() + 1, p1.rend());
            p1[0] = 0.0;

            std::vector<double> cs;
            cs.resize(p.size());
            std::vector<double> cs1;
            cs1.resize(p1.size());

            std::partial_sum(p.begin(),p.end(),cs.begin());
            std::partial_sum(p1.begin(),p1.end(),cs1.begin());

            int nextIndex = 0;
            double probWalkChoice = uniform(0.0,1.0);

            for(int k = 0; k < static_cast<int>(cs.size()); k++)
            {
                if(probWalkChoice > cs1[k] && probWalkChoice < cs[k])
                {
                    nextIndex = k;
                    break;
                }
            }

            startTx = currentView.at(nextIndex);
        }
    }

    startTx->countSelected++;
    return startTx;
}

Tx* AbstractModule::randomWalk(Tx* startTx, int &walkTime)
{
    walkTime = 0;
     
    while(startTx->isApproved)
    {
        walkTime++;
        auto currentView = startTx->approvedBy;

        if(currentView.size() == 0)
        {
            break;
        }

        if(currentView.size() == 1)
        {
            startTx = currentView.front();
        }

        else
        {   
            int nextIndex = intuniform(0,currentView.size() - 1);
            startTx = currentView.at(nextIndex);
        }
    }

    startTx->countSelected++;
    return startTx;
}

Tx* AbstractModule::getWalkStart(int backTrackDist) const
{
    int randomIndex = intuniform(0,myTips.size() - 1);
    auto it(myTips.begin());

    if(myTips.size() > 1) std::advance(it,randomIndex);
    
    auto startTip = *(it);

    while(!startTip->isGenesisBlock && backTrackDist > 0)
    {
        randomIndex = intuniform(0,startTip->approvedTx.size() - 1);
        startTip = startTip->approvedTx.at(randomIndex);
        backTrackDist--;
    }

    return startTip;
}

void AbstractModule::unionConflictTx(Tx* theSource, Tx* toUpdate)
{
    if(toUpdate->conflictTx.empty())
    {
        toUpdate->conflictTx = theSource->conflictTx;
        return; 
    }

    for(const auto key : theSource->conflictTx)
    {
        auto it = toUpdate->conflictTx.find(key.first);

        if(it == toUpdate->conflictTx.end()) 
        {
            toUpdate->conflictTx[key.first] = key.second;
        }

        else
        {
            if(key.second.first)
            {
                (*it).second.first = true;
            }

            if(key.second.second)
            {
                (*it).second.second = true;
            }    
        }
    }
}

bool AbstractModule::isLegitTip(Tx* tip) const
{
    for(const auto key : tip->conflictTx)
    {
        if(key.second.first && key.second.second)
        {
            return false;
        }
    }

    return true;
}

bool AbstractModule::ifConflictedTips(Tx* tip1, Tx* tip2) const
{
    std::map<std::string,std::pair<bool,bool>> outerMap;
    std::map<std::string,std::pair<bool,bool>> innerMap;

    if(tip1->conflictTx.size() >= tip2->conflictTx.size())
    {
        outerMap = tip2->conflictTx;
        innerMap = tip1->conflictTx;
    }

    else
    {
        outerMap = tip1->conflictTx;
        innerMap = tip2->conflictTx;
    }

    for(const auto keyOuter : outerMap)
    {
        auto it = innerMap.find(keyOuter.first);

        if(it != innerMap.end())
        {
            if((*it).second.first && keyOuter.second.second)
            {
                return true;
            }

            else if((*it).second.second && keyOuter.second.first)
            {
                return true;
            }
        }
    }

    return false;
}

void AbstractModule::updateConflictTx(Tx* startTx)
{
    VpTx visitedTx;
    
   _updateconflictTx(startTx,visitedTx,startTx->ID);

   for(auto tx : visitedTx)
   {
       tx->isVisited = false;
   }

   startTx->conflictTx["-" + startTx->ID] = std::make_pair(true,false);
   startTx->isVisited = false;
}

void AbstractModule::_updateconflictTx(Tx* currentTx, VpTx& visitedTx, std::string conflictID)
{
    if(currentTx->isVisited) return;

    currentTx->isVisited = true;
    visitedTx.push_back(currentTx);

    auto it = currentTx->conflictTx.find("-" + conflictID);
    if(it == currentTx->conflictTx.end()) currentTx->conflictTx["-" + conflictID] = std::make_pair(true,false);
    else (*it).second.first = true;
    
    for(auto tx : currentTx->approvedBy)
    {
        if(!tx->isVisited)
        {
            _updateconflictTx(tx,visitedTx,conflictID);
        }
    }
}

bool AbstractModule::isApp(Tx* startTx, std::string idToCheck)
{
    VpTx visitedTx;
    bool res = false;

   _isapp(startTx,visitedTx,idToCheck,res);

   for(auto tx : visitedTx)
   {
       tx->isVisited = false;
   }

   startTx->isVisited = false;

   return res;
}

void AbstractModule::_isapp(Tx* currentTx, VpTx& visitedTx, std::string idToCheck, bool& res)
{
    if(currentTx->isVisited) return;

    currentTx->isVisited = true;
    visitedTx.push_back(currentTx);

    if(currentTx->ID == idToCheck)
    {
        res = true;
        return;
    }

    for(auto tx : currentTx->approvedTx)
    {
        if(!tx->isVisited)
        {
            _isapp(tx,visitedTx,idToCheck,res);
        }
    }
}

int AbstractModule::computeWeight(Tx* tx)
{
    VpTx visitedTx;
    int weight = _computeweight(tx,visitedTx);

    for(auto tx : visitedTx)
    {
        tx->isVisited = false;
    }

    tx->isVisited = false;
    return weight + 1;
}

int AbstractModule::_computeweight(Tx* currentTx, VpTx& visitedTx)
{
    if(currentTx->isVisited)
    {
        return 0;
    }

    else if(currentTx->approvedBy.size() == 0)
    {
        currentTx->isVisited = true;
        visitedTx.push_back(currentTx);
        return 0;
    }

    currentTx->isVisited = true;
    visitedTx.push_back(currentTx);
    int weight = 0;

    for(auto tx : currentTx->approvedBy)
    {
        if(!tx->isVisited)
        {
            weight += 1 + _computeweight(tx,visitedTx);
        }
    }

    return weight;
}

void AbstractModule::computeConfidence(Tx* startTx, double conf)
{
    VpTx visitedTx;
    int dist = par("confDistance");
    _computeconfidence(startTx,visitedTx,dist,conf);

    for(auto tx : visitedTx)
    {
        tx->isVisited = false;
    }

    startTx->isVisited = false;
}

void AbstractModule::_computeconfidence(Tx* currentTx, VpTx& visitedTx, int distance, double conf)
{
    if(!currentTx->isVisited && distance >= 0)
    {
        currentTx->isVisited = true;
        currentTx->confidence += conf;
        visitedTx.push_back(currentTx);
        distance--;

        for(auto tx : currentTx->approvedTx)
        {
            if(!tx->isVisited)
            {
                _computeconfidence(tx,visitedTx,distance,conf);
            }
        }
    }
}

void AbstractModule::getAvgConf(Tx* startTx, double& avg)
{
    VpTx visitedTx;
    int dist = par("confDistance");
    _getavgconf(startTx,visitedTx,dist,avg);

    for(auto tx : visitedTx)
    {
        tx->isVisited = false;
    }

    startTx->isVisited = false;
}

void AbstractModule::_getavgconf(Tx* currentTx, VpTx& visitedTx, int distance, double& avg)
{
    if(!currentTx->isVisited && distance >= 0)
    {
        currentTx->isVisited = true;
        visitedTx.push_back(currentTx);
        avg += currentTx->confidence;
        distance--;

        for(auto tx : currentTx->approvedTx)
        {
            if(!tx->isVisited)
            {
                _getavgconf(tx,visitedTx,distance,avg);
            }
        }
    }
}

bool AbstractModule::isPresent(std::string txID) const
{
    auto it = std::find_if(myTangle.rbegin(), myTangle.rend(), [txID](const Tx* tx) {return tx->ID == txID;});
    return it != myTangle.rend();
}

Tx* AbstractModule::attachTx(simtime_t attachTime, VpTx chosenTips)
{
    //EV << "DEBUG extra\n" ;
    auto newTx = createTx();

    EV << "Issuing a new transaction : " << newTx->ID<< "\n";

    for(auto tip : chosenTips)
    {
        unionConflictTx(tip,newTx);
        tip->approvedBy.push_back(newTx);

        if(!(tip->isApproved))
        {
            tip->approvedTime = attachTime;
            tip->isApproved = true;
            updateMyTips(tip->ID);
        }
    }

    newTx->approvedTx = chosenTips;
    myTangle.push_back(newTx);
    myTips.push_back(newTx);
    return newTx;
}

Tx* AbstractModule::updateTangle(const dataUpdate* data)
{
    EV << "Updating the Tangle\n";

    auto newTx = new Tx(data->ID);
    EV << "updateNewTx: " << newTx->ID << "\n";
    newTx->issuedTime = simTime();
    
    if(newTx->ID[0] == '-')
    {
        newTx->conflictTx[newTx->ID] = std::make_pair(false,true);
        myBuffer.push_back(std::string(newTx->ID.begin() + 1, newTx->ID.end()));
    }

    for(const auto tipID : data->approvedTx)
    {
        auto it = std::find_if(myTangle.rbegin(), myTangle.rend(), [tipID](const Tx* tx) {return tx->ID == tipID;});
        
        if(it != myTangle.rend())
        {
            unionConflictTx(*it,newTx);
            newTx->approvedTx.push_back(*it);
            (*it)->approvedBy.push_back(newTx);

            if(!((*it)->isApproved))
            {
                (*it)->approvedTime = simTime();
                (*it)->isApproved = true;
                updateMyTips((*it)->ID);
            }
        }
    }

    myTangle.push_back(newTx);
    myTips.push_back(newTx);
    
    return newTx;
} 

void AbstractModule::updateMyTips(std::string tipID)
{
    auto it = std::find_if(myTips.begin(), myTips.end(), [tipID](const Tx* tx) {return tx->ID == tipID;});

    if(it != myTips.end())
    {
        myTips.erase(it);
    }
}

void AbstractModule::updateMyBuffer()
{
    for(auto it = myBuffer.begin(); it != myBuffer.end();)
    {
        auto itTx = std::find_if(myTangle.begin(), myTangle.end(), [it](const Tx* tx) {return tx->ID == *it;});

        if(itTx != myTangle.end())
        {
            it = myBuffer.erase(it);
            updateConflictTx(*itTx);
        }

        else
        {
            it++;
        } 
    }
}

void AbstractModule::spreadTx(cModule* senderModule, dataUpdate* data) 
{
    EV << " Sending " << data->ID << " to all nodes\n";

    for(int i = 0; i < gateSize("out"); i++)
    {
        cGate *g = gate("out",i);

        if(!g->pathContains(senderModule))
        {
            auto copyData = new dataUpdate;
            copyData->ID = data->ID;
            copyData->approvedTx = data->approvedTx;

            msgUpdate->setContextPointer(copyData);
            send(msgUpdate->dup(),"out",i);
        }
    }
}

void AbstractModule::spreadAuth(cModule* senderModule, dataAuth* data)
{
    EV << "Enviando AUTH con hash: " << data->hash << "\n";

}

//##################################################################################################################################
//##################################################################################################################################
//##################################################################################################################################

//Broadcast para el proceso de Autenticaci�n - Bloque 1

void AbstractModule::sendASO(string ID)
{
    auto data = new dataASO;
    data->ID = ID;

    for(int i = 0; i < gateSize("out"); i++)
    {
        auto copyData = new dataASO;
        copyData->ID = data->ID;

        msgASO->setContextPointer(copyData);
        send(msgASO->dup(),"out",i);
    }
    currentTx += sx1272_tx;

    delete data;
}

string AbstractModule::getPassDinamic()
{
    EV << "Obteniendo la pass dinamica..." << endl;

    //leer contrase�as del diccionario
    //std::string path = "./data/pass" + ID + ".csv";

    //****** Se obtiene primero una de pass aleatoria de las 200 disponibles ***********
    std::string path = "./data/passDict.csv";
    std::fstream file;
    file.open(path,std::ios::in);

    if(!file.is_open()) throw std::runtime_error("No se pudo abrir el CSV!");
    std::string line;
    int i = 1;
    srand(simTime().raw());
    int randPass = rand() % (passDictLength - 1);  // Genera un entero aleatorio desde 0 hasta Length
    string input1, output1;

    while(getline(file,line))
    {
        if (i == randPass)
        {
            input1 = line;
            break;
        }
        i++;
    }
    file.close();
    EV << "Pass: " << input1 << endl;

    //********** Se obtiene una salt aleatoria de las 50 disponibles *************
    std::string path1 = "./data/salDict.csv";
    std::fstream file1;
    file1.open(path1,std::ios::in);

    if(!file1.is_open()) throw std::runtime_error("No se pudo abrir el CSV!");
    std::string line1;
    int j = 1;
    srand(simTime().raw());
    int randSalt = rand() % (saltDictLength - 1);
    string input2, output2;

    while(getline(file1,line1))
    {
        if (j == randSalt)
        {
            input2 = line1;
            break;
        }
        j++;
    }
    file1.close();
    //EV << "Salt: " << input2 << " Rand: " << randSalt << endl;
    EV << "Salt: " << input2 << endl;
    actualSaltHash = sha256(input2);

    output1 = input1 + input2;
    output2 = sha256(output1);
    EV << "Pass + salt: " << output1 << "\nCon Hash igual a: " << output2 << endl;

    return output2;

}

string AbstractModule::getTransactionData(int nTransaction)
{


    std::string path = "./data/tracking/node" + ID + "Transaction" + std::to_string(nTransaction) + ".csv";
    std::fstream file;
    file.open(path,std::ios::in);

    EV << "Obteniendo la transaccion N. " << nTransaction << "\nAccediendo a " << path << endl;

    if(!file.is_open()) throw std::runtime_error("No se pudo abrir el CSV con la transaccion indicada!");

    std::string line;
    string stringTransaction = "Datos de " + ID;

    while(getline(file,line)) stringTransaction = stringTransaction + " " + line;

    file.close();

    EV << "stringTransaction: " << stringTransaction << endl;

    return stringTransaction;
}

void AbstractModule::setPassDict() //NO USADO
{
    string seedTemp;

    if (ID == "[0]") {
        seedTemp = seedNodo0;
    } else if (ID == "[1]") {
        seedTemp = seedNodo1;
    } else if (ID == "[2]") {
        seedTemp = seedNodo2;
    } else if (ID == "[3]") {
        seedTemp = seedNodo3;
    } else if (ID == "[4]") {
        seedTemp = seedNodo4;
    } else if (ID == "[5]") {
        seedTemp = seedNodo5;
    } else if (ID == "[6]") {
        seedTemp = seedNodo6;
    } else if (ID == "[7]") {
        seedTemp = seedNodo7;
    } else if (ID == "[8]") {
        seedTemp = seedNodo8;
    } else if (ID == "[9]") {
        seedTemp = seedNodo9;
    }

    EV << "Generando diccionario de Pass a partir de la semilla: " << seedTemp << endl;

    //leer contrase�as del diccionario
    std::fstream file;
    std::string path = "./data/pass" + ID + ".csv";
    remove(path.c_str());
    file.open(path,std::ios::app);
    std::vector<std::string> newPass;


    for(int u = 0; u < passDictLength; u++)
    {
        newPass = generateFromSeed(seedTemp);
        std::string s;
        for (const auto &piece : newPass) {
            s += piece;
        }
        file << s << "\n";
    }

    file.close();
}

std::vector<std::string> AbstractModule::generateFromSeed(string seed) //NO USADO
{
    //Crea un char array y almacena la semilla
    char *cstr = new char[seed.length() + 1];
    strcpy(cstr, seed.c_str());

    //Crea un vector string para la nueva pass
    std::vector<std::string> newPass;
    int string_length = strlen(cstr) - 1;
    //EV << "cstr: " << cstr << " ; length: " << strlen(cstr) << endl;

    //srand(time(0));


    //Toma partes aleatorias de la semilla para generar la nueva pass
    for(int i = 0; i < 8; i++)
    {
        //string stemp = std::string(1, cstr[rand() % string_length]);
        int rando =  intrand(string_length);

        //EV << "rando: " << rando << endl;
        string stemp = std::string(1, cstr[rando]);
        newPass.push_back(stemp);
    }

    delete [] cstr;
    return newPass;
}


void AbstractModule::sendAuthReq(string IDRx, string IDTx)
{
    auto data = new dataAuthReq;
    data->IDRx = IDRx;
    data->IDTx = IDTx;
    //data->hash = "e73b79a0b10f8cdb6ac7dbe4c0a5e25776e1148784b86cf98f7d6719d472af69";
    //data->hash = getPassDinamic();
    data->hash = actualPassHash;

    if (ID == "[0]") {
        for(int i = 0; i < gateSize("out") - (nIslas - 1); i++)
        {
            auto copyData = new dataAuthReq;
            copyData->IDRx = data->IDRx;
            copyData->IDTx = data->IDTx;
            copyData->hash = data->hash;

            msgAuthReq->setContextPointer(copyData);
            send(msgAuthReq->dup(),"out",i);
        }
    } else if (ID == "[10]") {
        for(int i = 1; i < gateSize("out") - (nIslas - 2); i++)
        {
            auto copyData = new dataAuthReq;
            copyData->IDRx = data->IDRx;
            copyData->IDTx = data->IDTx;
            copyData->hash = data->hash;

            msgAuthReq->setContextPointer(copyData);
            send(msgAuthReq->dup(),"out",i);
        }
    } else if (ID == "[20]") {
        for(int i = 2; i < gateSize("out") - (nIslas - 3); i++)
        {
            auto copyData = new dataAuthReq;
            copyData->IDRx = data->IDRx;
            copyData->IDTx = data->IDTx;
            copyData->hash = data->hash;

            msgAuthReq->setContextPointer(copyData);
            send(msgAuthReq->dup(),"out",i);
        }
    } else if (ID == "[30]") {
        for(int i = 3; i < gateSize("out") ; i++)
        {
            auto copyData = new dataAuthReq;
            copyData->IDRx = data->IDRx;
            copyData->IDTx = data->IDTx;
            copyData->hash = data->hash;

            msgAuthReq->setContextPointer(copyData);
            send(msgAuthReq->dup(),"out",i);
        }
    } else {
        for(int i = 0; i < gateSize("out"); i++)
        {
            cGate *g = gate("out",i);

            if (g->isConnected()) {
                auto copyData = new dataAuthReq;
                copyData->IDRx = data->IDRx;
                copyData->IDTx = data->IDTx;
                copyData->hash = data->hash;

                msgAuthReq->setContextPointer(copyData);
                send(msgAuthReq->dup(),"out",i);
            } else {
                std::cout << "Puerta " << i << " del nodo " << ID << " desconectada!" << endl;
            }

        }
    }

    currentTx += sx1272_tx;

    delete data;
}


void AbstractModule::sendAuth(string hash, string IDRx, string IDTx)
{
    auto data = new dataAuth;
    data->IDRx = IDRx;
    data->hash = hash;
    data->IDTx = IDTx;

    for(int i = 0; i < gateSize("out"); i++)
    {
        auto copyData = new dataAuth;
        copyData->IDRx = data->IDRx;
        copyData->IDTx = data->IDTx;
        copyData->hash = data->hash;

        msgAuth->setContextPointer(copyData);
        send(msgAuth->dup(),"out",i);
    }
    currentTx += sx1272_tx;

    delete data;
}

void AbstractModule::sendAuthAttack(string hash, string IDRx, string IDTx, int nAttack)
{
    auto data = new dataAuth;
    data->IDRx = IDRx;
    data->hash = hash;
    data->IDTx = IDTx;

    for(int i = 0; i < gateSize("out"); i++)
    {
       auto copyData = new dataAuth;
       copyData->IDRx = data->IDRx;
       copyData->IDTx = data->IDTx;
       copyData->hash = data->hash;

       msgAuth->setContextPointer(copyData);
       send(msgAuth->dup(),"out",i);
    }
    currentTx += sx1272_tx;

    delete data;
}

void AbstractModule::sendAuthAck(string IDslave, string IDmaster)
{
    auto data = new dataAuthAck;
    data->ID = IDslave;
    data->IDmaster = IDmaster;

    if (ID == "[0]") {
        for(int i = 0; i < gateSize("out") - (nIslas - 1); i++)
        {
            auto copyData = new dataAuthAck;
            copyData->ID = data->ID;
            copyData->IDmaster = data->IDmaster;

            msgAuthAck->setContextPointer(copyData);
            send(msgAuthAck->dup(),"out",i);
        }
    } else if (ID == "[10]") {
        for(int i = 1; i < gateSize("out") - (nIslas - 2); i++)
        {
            auto copyData = new dataAuthAck;
            copyData->ID = data->ID;
            copyData->IDmaster = data->IDmaster;

            msgAuthAck->setContextPointer(copyData);
            send(msgAuthAck->dup(),"out",i);
        }
    } else if (ID == "[20]") {
        for(int i = 2; i < gateSize("out") - (nIslas - 3); i++)
        {
            auto copyData = new dataAuthAck;
            copyData->ID = data->ID;
            copyData->IDmaster = data->IDmaster;

            msgAuthAck->setContextPointer(copyData);
            send(msgAuthAck->dup(),"out",i);
        }
    } else if (ID == "[30]") {
        for(int i = 3; i < gateSize("out"); i++)
        {
            auto copyData = new dataAuthAck;
            copyData->ID = data->ID;
            copyData->IDmaster = data->IDmaster;

            msgAuthAck->setContextPointer(copyData);
            send(msgAuthAck->dup(),"out",i);
        }
    } else {
        for(int i = 0; i < gateSize("out"); i++)
        {
            auto copyData = new dataAuthAck;
            copyData->ID = data->ID;
            copyData->IDmaster = data->IDmaster;

            msgAuthAck->setContextPointer(copyData);
            send(msgAuthAck->dup(),"out",i);
        }
    }
    currentTx += sx1272_tx;

    delete data;
}

void AbstractModule::sendSensorData(dataSensor* data) //Envia por la gate [0] los datos de sensores
{
    for(int i = 0; i < 1; i++)
    {
        cGate *g = gate("out",i);

        auto copyData = new dataSensor;
        copyData->destinoID = data->destinoID;
        copyData->origenID = data->origenID;
        copyData->sensPH = data->sensPH;
        copyData->sensTEMP = data->sensTEMP;

        msgSensorData->setContextPointer(copyData);
        send(msgSensorData->dup(),"out",i);
    }
}

void AbstractModule::storeTransaction() //Genera un csv con la transaccion de turno
{
    EV << "Creando Transaccion N. " << countSensorTx << endl;
    std::fstream file1;
    std::string path1 = "./data/tracking/node" + ID + "Transaction" + std::to_string(countSensorTx) + ".csv";
    remove(path1.c_str());
    file1.open(path1,std::ios::app);
    file1 << "Nodo;sensorPH;sensorTEMP;\n";

    for (auto piece: actualTransaction)
    {
        file1 << piece << ";\n";
    }

    std::string stringTemporal;
    for (const auto &datos : actualTransactionData)
    {
        stringTemporal += datos;
    }

    actualTransaction.clear();
    actualTransactionData.clear();
    file1.close();


}

string AbstractModule::readTransaction(int transactionIndex)
{
    std::fstream file1;
    std::string path1 = "./data/tracking/nodeTransaction" + std::to_string(transactionIndex) + ".csv";
    file1.open(path1,std::ios::app);

    std::vector<std::string> transaction;

    string temp;

    while (file1 >> temp) {
        EV << "*******" << temp << endl;
        //getline(file1, line);
    }

    return temp;
}

void AbstractModule::spreadAso(cModule* senderModule, dataUpdateAso* data)
{
    if (ID == "[0]" || ID == "[10]" || ID == "[20]" || ID == "[30]") EV << "Informando la asociacion de " << data->ID << " por la BSTA " << data->IDmaster  << "\nEnviando a todos los nodos!\n";
    else EV << "Informando la asociacion de " << data->ID << " por el nodo " << data->IDmaster  << "\nEnviando a todos los nodos!\n";

    if (ID == "[0]") {
        for(int i = 0; i < gateSize("out") - (nIslas - 1); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataUpdateAso;
                copyData->ID = data->ID;
                copyData->IDmaster = data->IDmaster;

                msgUpdateAso->setContextPointer(copyData);
                send(msgUpdateAso->dup(),"out",i);
            }
        }
    } else if (ID == "[10]") {
        for(int i = 1; i < gateSize("out") - (nIslas - 2); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataUpdateAso;
                copyData->ID = data->ID;
                copyData->IDmaster = data->IDmaster;

                msgUpdateAso->setContextPointer(copyData);
                send(msgUpdateAso->dup(),"out",i);
            }
        }
    } else if (ID == "[20]") {
        for(int i = 2; i < gateSize("out") - (nIslas - 3); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataUpdateAso;
                copyData->ID = data->ID;
                copyData->IDmaster = data->IDmaster;

                msgUpdateAso->setContextPointer(copyData);
                send(msgUpdateAso->dup(),"out",i);
            }
        }
    } else if (ID == "[30]") {
        for(int i = 3; i < gateSize("out"); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataUpdateAso;
                copyData->ID = data->ID;
                copyData->IDmaster = data->IDmaster;

                msgUpdateAso->setContextPointer(copyData);
                send(msgUpdateAso->dup(),"out",i);
            }
        }
    } else if ((ID == "[4]" || ID == "[7]" || ID == "[9]") && (nbAttackerNode > 0)){
        for(int i = 0; i < gateSize("out") - 1; i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataUpdateAso;
                copyData->ID = data->ID;
                copyData->IDmaster = data->IDmaster;

                msgUpdateAso->setContextPointer(copyData);
                send(msgUpdateAso->dup(),"out",i);
            }
        }
    } else {
        for(int i = 0; i < gateSize("out"); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataUpdateAso;
                copyData->ID = data->ID;
                copyData->IDmaster = data->IDmaster;

                msgUpdateAso->setContextPointer(copyData);
                send(msgUpdateAso->dup(),"out",i);
            }
        }
    }

}

void AbstractModule::spreadAttacker(cModule* senderModule, dataAttacker* data, int aislado)
{
    EV << "Informando que el nodo " << data->IDattacker << " se ha marcado como ATACANTE! gracias al nodo " << data->ID << endl;

    if (ID == "[0]"){
        for(int i = 0; i < gateSize("out") - (nIslas - 1); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataAttacker;
                copyData->ID = data->ID;
                copyData->IDattacker = data->IDattacker;

                msgAttacker->setContextPointer(copyData);
                send(msgAttacker->dup(),"out",i);
            }
        }
    } else if (ID == "[10]"){
        for(int i = 1; i < gateSize("out") - (nIslas - 2); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataAttacker;
                copyData->ID = data->ID;
                copyData->IDattacker = data->IDattacker;

                msgAttacker->setContextPointer(copyData);
                send(msgAttacker->dup(),"out",i);
            }
        }
    } else if (ID == "[20]"){
        for(int i = 2; i < gateSize("out") - (nIslas - 3); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataAttacker;
                copyData->ID = data->ID;
                copyData->IDattacker = data->IDattacker;

                msgAttacker->setContextPointer(copyData);
                send(msgAttacker->dup(),"out",i);
            }
        }
    } else if (ID == "[30]"){
        for(int i = 3; i < gateSize("out"); i++)
        {
            cGate *g = gate("out",i);

            if(!g->pathContains(senderModule))
            {
                auto copyData = new dataAttacker;
                copyData->ID = data->ID;
                copyData->IDattacker = data->IDattacker;

                msgAttacker->setContextPointer(copyData);
                send(msgAttacker->dup(),"out",i);
            }
        }
    } else {
        for(int i = 0; i < gateSize("out"); i++)
        {
            cGate *g = gate("out",i);

            if (g->isConnected()) {
                if(!g->pathContains(senderModule))
                {
                    auto copyData = new dataAttacker;
                    copyData->ID = data->ID;
                    copyData->IDattacker = data->IDattacker;

                    msgAttacker->setContextPointer(copyData);
                    send(msgAttacker->dup(),"out",i);
                }
            } else {
                std::cout << "Puerta " << i << " del nodo " << ID << " desconectada!" << endl;
            }
        }
    }
}

void AbstractModule::isolateAttacker()
{
    std::cout << "*Nodo " << ID << " aislando atacante..." << endl;
    cGate *attackerGate = gate("out", gateSize("out") - 1); //Apunta a la �ltima gate agreada
    //attackerGate->getChannel()->isDisabled();
    attackerGate->disconnect();

}

//*******************************************************************************************************************
json::JSON jsonObj; //Blockchain final
json::JSON jsonTemp; //Blockchain usado para competir

string AbstractModule::mineBlock2(uint32_t nDifficulty, int nNonce, string sData, string tTime, int index, string sPrevHash){
    char cstr[nDifficulty + 1];
    string sHash;
    for (uint32_t i = 0; i < nDifficulty; ++i) {
        cstr[i] = '0';
    }
    cstr[nDifficulty] = '\0';

    string str(cstr);

    do {
        nNonce++;
        sHash = calculateHash(index, tTime, sData, nNonce, sPrevHash);
    } while (sHash.substr(0, nDifficulty) != str);

    EV << "** Bloque minado! " << sHash << endl;
    jsonObj[index]["nonce"] = nNonce;
    return sHash;
}

string AbstractModule::calculateHash(int nIndex, string tTime, string sData, int nNonce, string sPrevHash){
    std::stringstream ss;
    ss << nIndex << tTime << sData << nNonce << sPrevHash;

    return sha256(ss.str());
}

void AbstractModule::newBlock(string data, int index, int nNonce, string time) {
    jsonObj[index]["prevHash"] = jsonObj[index - 1]["hash"].ToString();
    jsonObj[index]["index"] = index;
    jsonObj[index]["data"] = data;
    //jsonObj[index - 1]["nonce"] = nNonce;
    jsonObj[index]["time"] = time;
    jsonObj[index]["hash"] = mineBlock2(nDifficulty, jsonObj[index]["nonce"].ToInt(), data, time, index, jsonObj[index]["prevHash"].ToString());

    EV << "** BSTA ** " << ID << "newBlock" << endl;
    EV << jsonObj << endl;

    //Guardar minado temporalmente
    //EV << "+++ TEMPORAL" << endl;
    indexTemporal = jsonObj[blockIndex]["index"].ToInt();
    nonceTemporal = jsonObj[blockIndex]["nonce"].ToInt();
    dataTemporal = jsonObj[blockIndex]["data"].ToString();
    hashTemporal = jsonObj[blockIndex]["hash"].ToString();
    timeTemporal = jsonObj[blockIndex]["time"].ToString();
    prevHashTemporal = jsonObj[blockIndex]["prevHash"].ToString();
    //EV  << indexTemporal << "\n" << nonceTemporal << "\n" << dataTemporal << "\n" << hashTemporal << "\n" << timeTemporal << "\n" << prevHashTemporal << "\n" << endl;
}

void AbstractModule::updateBlock(int index, int nonce, string data, string hash, string time, string prevHash) {
    jsonObj[blockIndex]["index"] = blockIndex;
    jsonObj[blockIndex]["nonce"] = nonce;
    jsonObj[blockIndex]["data"] = data;
    jsonObj[blockIndex]["hash"] = hash;
    jsonObj[blockIndex]["time"] = time;
    jsonObj[blockIndex]["prevHash"] = prevHash;

    EV << "* BLOCKCHAIN actualizada para " << negrita(ID) << " *" << endl;
    EV << jsonObj << endl;

}


void AbstractModule::addBlockChain(int index, string data)
{
    Blockchain bChain = Blockchain();
    bChain.AddBlock(Block(index, data));

    newBlock(data, index, -1, simTime().ustr());
    if (ID == "[0]") {
        sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[10]");
        sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[20]");
        if (nIslas > 3) sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[30]");
    } else if (ID == "[10]") {
        //if (!pruebaIslaCaida) {
            sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[0]");
            sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[20]");
            if (nIslas > 3) sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[30]");
        //} else EV << "*La isla del nodo [10], se encuentra caida!" << endl;

    } else if (ID == "[20]") {
        sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[0]");
        sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[10]");
        if (nIslas > 3) sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[30]");
    } else if (ID == "[30]") {
        sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[0]");
        sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[10]");
        sendNonce(index, jsonObj[index]["nonce"].ToInt(), "[20]");
    }

    if (topology == "UnaIsla") {
        EV << "** No hay islas vecinas, sin competicion! ** " << endl;
    } else {
        //Self message
        auto msgData = new dataNonce;
        msgData->index = index;
        msgData->nonce = jsonObj[index]["nonce"].ToInt();
        msgData->origenID = ID;
        msgData->destinoID = ID;

        auto copyData = new dataNonce;
        copyData->index = msgData->index;
        copyData->nonce = msgData->nonce;
        copyData->origenID = msgData->origenID;
        copyData->destinoID = msgData->destinoID;
        msgDataNonce->setContextPointer(copyData);

        scheduleAt(simTime(), msgDataNonce->dup()); //selfMsg

        delete msgData;
    }

}

void AbstractModule::BlockGenesis()
{
    jsonObj[0]["index"] = 0;
    jsonObj[0]["nonce"] = -1;
    jsonObj[0]["data"] = "Bloque Genesis";
    jsonObj[0]["hash"] = sha256("Bloque Genesis");
    jsonObj[0]["time"] = simTime().ustr();
    jsonObj[0]["prevHash"] = "0";

}

void AbstractModule::callSendBlock(int newIndex, string dest)
{
    //EV << "callSendBlock para " << dest << endl;
    //EV << "Temp enviado por " << ID << endl;
    //EV  << indexTemporal << "\n" << nonceTemporal << "\n" << dataTemporal << "\n" << hashTemporal << "\n" << timeTemporal << "\n" << prevHashTemporal << "\n" << endl;
    sendBlockReq(newIndex, nonceTemporal, dataTemporal, hashTemporal, timeTemporal, prevHashTemporal, dest);
}

void AbstractModule::sendBlockReq(int index, int nonce, string data, string hash, string time, string prevHash, string destID)
{
    auto msgData = new dataBlock;
    msgData->index = index;
    msgData->nonce = nonce;
    msgData->data = data;
    msgData->hash = hash;
    msgData->time = time;
    msgData->prevHash = prevHash;
    msgData->origenID = ID;
    msgData->destinoID = destID;

    for(int i = 0; i < gateSize("out"); i++)
        {
            auto copyData = new dataBlock;
            copyData->index = msgData->index;
            copyData->nonce = msgData->nonce;
            copyData->data = msgData->data;
            copyData->hash = msgData->hash;
            copyData->prevHash = msgData->prevHash;
            copyData->origenID = msgData->origenID;
            copyData->destinoID = msgData->destinoID;
            copyData->time = msgData->time;

            msgDataBlock->setContextPointer(copyData);
            send(msgDataBlock->dup(),"out",i);
        }

    currentTx += sx1272_tx;

    delete msgData;
}

void AbstractModule::sendNonce(int index, int nonce, string destID)
{
    auto msgData = new dataNonce;
    msgData->index = index;
    msgData->nonce = nonce;
    msgData->origenID = ID;
    msgData->destinoID = destID;

    for(int i = 0; i < gateSize("out"); i++)
    {
        auto copyData = new dataNonce;
        copyData->index = msgData->index;
        copyData->nonce = msgData->nonce;
        copyData->origenID = msgData->origenID;
        copyData->destinoID = msgData->destinoID;

        msgDataNonce->setContextPointer(copyData);
        send(msgDataNonce->dup(),"out",i);
    }
    currentTx += sx1272_tx;

    delete msgData;
}
//*****************************************************************************************************************
void AbstractModule::broadcastTx(const Tx* newTx)
{
    auto data = new dataUpdate;
    data->ID = newTx->ID;

    for(const auto approvedTips : newTx->approvedTx)
    {
        data->approvedTx.push_back(approvedTips->ID);
    }

    for(int i = 0; i < gateSize("out"); i++)
    {
        auto copyData = new dataUpdate;
        copyData->ID = data->ID;
        copyData->approvedTx = data->approvedTx;

        msgUpdate->setContextPointer(copyData);
        send(msgUpdate->dup(),"out",i);
    }

    delete data;
}

void AbstractModule::deleteTangle()
{
    for(auto tx : myTangle)
    {
        delete tx;
    }
}

float AbstractModule::calcularDistancia(string origenID, string destinoID) {

    std::string path = "./data/positions.csv";
    std::fstream file;
    file.open(path,std::ios::in);

    if(!file.is_open()) throw std::runtime_error("No se pudo abrir el CSV!");
    std::string line, word;

    std::vector<std::vector<string>> content;
    std::vector<string> row;

    int x1,x2,y1,y2; //Formula distancia entre dos puntos

    while(getline(file,line))
    {
        row.clear();
        std::stringstream str(line);
        while(getline(str, word, ';'))
        row.push_back(word);
        content.push_back(row);

    }
    file.close();

    for (int i = 0; i < content.size(); i++) {
        for (int j = 0; j < content[i].size(); j++) {
            if (content[i][j] == origenID) {
                x1 = std::stoi(content[i][j + 1]);
                y1 = std::stoi(content[i][j + 2]);
            }
            if (content[i][j] == destinoID) {
                x2 = std::stoi(content[i][j + 1]);
                y2 = std::stoi(content[i][j + 2]);
            }
            //EV << content[i][j] << " ";
        }
        //EV << endl;
    }

    float distCalc = std::sqrt(std::pow((x2 - x1),2) + std::pow((y2 - y1),2));
    //EV << "Distancia = " << distCalc << endl;
    return distCalc;
}

float AbstractModule::calcularRxPower(int txPowerdBm, float freq, float distance){
    //https://www.pasternack.com/t-calculator-fspl.aspx

    float pathLoss_dB = referenceLoss_dB + 10*pathLossExponent*std::log10(distance/referenceDistance) + 21 * std::log10(freq/referenceFreq);
    float rxPowerdBm = txPowerdBm - pathLoss_dB;
    EV << "\x1b[1m\x1b[32m*PathLoss: " << pathLoss_dB << "dB\x1b[0m & \x1b[1m\x1b[35mRxPowerdBm: " << rxPowerdBm << "dBm\x1b[0m" << endl;
    rxPowerVector.recordWithTimestamp(simTime(), rxPowerdBm);
    return rxPowerdBm;
}

string AbstractModule::negrita(string palabra) { // Metodo para colocar palabras o frases en negritas
    string negrita = "\x1b[1m" + palabra + "\x1b[0m";
    return negrita;
}

void AbstractModule::_initialize()
{
    //*************
    //EV << "PROBANDO BOLD: " << "\x1b[1mHOLI\x1b[0m" << endl;
    //EV << "PROBANDO BOLD2: " << negrita("HOLO") << endl;
    // ROJO \x1b[1m\x1b[31m
    // AZUL \x1b[1m\x1b[34m

    //****** BSTA *******//
    nIslas = getParentModule()->par("nIslas"); //cantidad de islas
    nbAttackerNode = getParentModule()->par("nbAttackerNode");
    nDifficulty = getParentModule()->par("nDifficulty");
    std::string currentTopo = getParentModule()->par("topology");
    topology = currentTopo;

    //****** SENSORES*******//
    countSensorTx = 1;
    maxSensorTx = getParentModule()->par("maxSensorTx");

    //******* PATHLOSS ********//
    pathLossExponent = getParentModule()->par("pathLossExponent"); //coeficiente
    referenceDistance = getParentModule()->par("referenceDistance"); //metros
    referenceFreq = getParentModule()->par("referenceFreq"); //MHz
    referenceLoss_dB = getParentModule()->par("referenceLoss"); //30dB de perdida a 1m

    //********* DOS *************
    countDOS = getParentModule()->par("countDOS");
    txCount = 0;

    //********* ISLAS CAIDAS ***********
    islaCaida1 = getParentModule()->par("islaCaida1");
    islaCaida2 = getParentModule()->par("islaCaida2");
    islaCaida3 = getParentModule()->par("islaCaida3");
    islaCaida4 = getParentModule()->par("islaCaida4");

    //***************

    if (nbAttackerNode > 0) {
        ID = "[" + std::to_string(getId() - 5) + "]";
        if (ID == "[-2]") {
            ID = "[99]";
        } else if (ID == "[-1]") {
            ID = "[100]";
        }
    } else {
        ID = "[" + std::to_string(getId() - 3) + "]";
    }

    rateMean = par("rateMean");
    powTime = par("powTime");
    txLimit = par("transactionLimit");

    createGenBlock();
    BlockGenesis();

    msgIssue = new cMessage("Emitiendo nueva transaccion",ISSUE);
    msgPoW = new cMessage("Tiempo para PoW",POW);
    msgUpdate = new cMessage("Broadcast transaccion nueva",UPDATE);
    msgAuth = new cMessage("Autenticando",AUTH);

    //Pers
    msgBLOQ11 = new cMessage("Inicio del proceso bloque 1",BLOQ11);
    msgASO = new cMessage("Peticion de asociacion",ASO);
    msgAuthReq = new cMessage("Respuesta a la asociacion",ASORESP);
    msgAuthAck = new cMessage("ACK de asociacion",ASOACK);
    msgUpdateAso = new cMessage("Broadcast de UPDATE",UPDATEASO);
    msgUpdatePass = new cMessage("Cambio de pass dinamica",UPDATEPASS);
    msgAttacker = new cMessage("Broadcast de ATTACKER INFO",ATTACKER);
    msgSensorData = new cMessage("Transaccion con datos", SENSORDATA);
    msgStartTx = new cMessage("Inicia la Transaccion con datos", STARTTX);
    msgDataBlock = new cMessage("Actualiza la BLOCKCHAIN", DATABLOCK);
    msgCompeteBlock = new cMessage("Inicio de proceso de competicion",COMPETE);
    msgDataNonce = new cMessage("Nonce obtenida de minar al competir",NONCE);
    msgTimeOut = new cMessage("Una o mas islas no disponibles",TIMEOUT);

    rxPowerVector.setName("rxPower vector");
    currentTxVector.setName("currentTx vector");
    currentRxVector.setName("currentRx vector");


    /*
    msgAuthReq->getDisplayString().setTagArg("i",0,"msg/mail");
    msgAuthAck->getDisplayString().setTagArg("i",0,"msg/mail");
    msgUpdateAso->getDisplayString().setTagArg("i",0,"msg/mail");
    msgSensorData->getDisplayString().setTagArg("i",0,"msg/mail");
    msgDataBlock->getDisplayString().setTagArg("i",0,"msg/mail");
    */
    /*
    msgIssue->getDisplayString()->insertTag("o");
    msgIssue->getDisplayString()->insertTagArg("o",0,"red");
    msgIssue->getDisplayString()->insertTagArg("o",1,"blue");
    msgIssue->getDisplayString()->insertTagArg("o",2,2);
    */

    //EV << msgIssue->getFullName() << "; geDisplayString: " << msgIssue->getDisplayString() << endl ;
    //EV << "AbstractModule::initialize:ID-> " << ID << endl;


}

void AbstractModule::_finish(bool exportTangle, std::pair<bool,bool> exportTipsNumber)
{
    EV << "Exporting data to csv files and clearing memory\n";

    recordScalar("peso", peso);
    recordScalar("currentTotal", currentTotal);
    recordScalar("currentSleep", currentSleep);
    recordScalar("currentTx", currentTx);
    recordScalar("currentRx", currentRx);
    rxPowerSuma = rxPowerSuma / numeroRx;
    recordScalar("rxPowerAvg", rxPowerSuma);

    if(exportTangle)
    {
        printTangle();
    }

    if(exportTipsNumber.first)
    {
        printTipsLeft(exportTipsNumber.second);
    }

    printStats(true);

    deleteTangle();
    delete msgIssue;
    delete msgPoW;
    delete msgUpdate;
    delete msgAuth;
    delete msgBLOQ11;
    delete msgASO;
    delete msgAuthReq;
    delete msgAuthAck;
    delete msgUpdatePass;
    delete msgUpdateAso;
    delete msgAttacker;
    delete msgStartTx;
    delete msgSensorData;
    delete msgDataBlock;
    delete msgDataNonce;
    delete msgCompeteBlock;
    delete msgTimeOut;
}
