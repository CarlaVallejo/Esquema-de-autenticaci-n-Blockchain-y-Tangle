//includes
#pragma once

#include <omnetpp.h>
#include <fstream>
#include <algorithm>
#include <numeric>
#include "omp.h"
#include "Structures.h"
#include "sha256.h"
#include <iostream>

//password seed
#include <cstdlib>
#include <ctime>

//blockchain
//#include "json.h"

using namespace omnetpp;
using std::string;

/*
#if defined(Py_EXPORTED_SYMBOL)
#  define Py_EXPORTED_SYMBOL OPP_DLLEXPORT
#elif defined(Py_IMPORTED_SYMBOL)
#  define Py_IMPORTED_SYMBOL OPP_DLLIMPORT
#endif
*/

//Abstract class for the HonestModule class & MaliciousModule class
class AbstractModule : public cSimpleModule
{
    public:
        Tx* createTx(); //generate a new transaction
        void createGenBlock(); //generate the Genesis block;

        //getter 
        int getTxCount() const;
        int getTxLimit() const;

        //setter
        void setTxLimit(int newLimit);

        //track data
        void printTangle() const; //export the Tangle in CSV format to be drawned with the python script 
        void printTipsLeft(bool ifDeleteFile) const; //export the amount of tips at the end of the simulation in a CSV file
        void printStats(bool ifDeleteFile = false) const; //write in a CSV file some stats of the simulation at a given time (i.e when the function is called) 

        /* return a vector of tuple containing:
            - the pointer of the selected tip after the random walk
            - the number of time that this tip has been selected
            - its walk time during the random walk
        */
        std::vector<std::tuple<Tx*,int,int>> getSelectedTips(double alphaVal, int W, int N);

        //TSA
        VpTx IOTA(double alphaVal, int W, int N);
        VpTx GIOTA(double alphaVal, int W, int N);
        VpTx EIOTA(double p1, double p2, double lowAlpha, double highAlpha, int W, int N);

        //return tips using the TSA method set in the NED file 
        VpTx getTipsTSA();

        //random walk based on a Markov Chain Monte Carlo (MCMC)
        Tx* weightedRandomWalk(Tx* startTx, double alphaVal, int &walkTime);
        Tx* randomWalk(Tx* startTx, int &walkTime);

        //select start site for the random walk
        Tx* getWalkStart(int backTrackDist) const;

        void unionConflictTx(Tx* theSource, Tx* toUpdate); //get the union between two conflictTx attribute
        bool isLegitTip(Tx* tip) const; //check if a tip is legit (i.e do not approves conflicted transaction)
        bool ifConflictedTips(Tx* tip1, Tx* tip2) const; //check if there is a conflict between two tips

        //update the conflictTx attribute of a transaction
        void updateConflictTx(Tx* startTx);
        void _updateconflictTx(Tx* currentTx, VpTx& visitedTx, std::string conflictID);

        //check if a transaction approves directly or indirectly an another transaction 
        bool isApp(Tx* startTx, std::string idToCheck);
        void _isapp(Tx* currentTx, VpTx& visitedTx, std::string idToCheck, bool& res);

        //compute the weight of a transaction
        int computeWeight(Tx* tx);
        int _computeweight(Tx* currentTx, VpTx& visitedTx);
        
        //compute the confidence for each transaction
        void computeConfidence(Tx* startTx, double conf);
        void _computeconfidence(Tx* currentTx, VpTx& visitedTx, int distance, double conf);

        //compute the avg confidence of a tip
        void getAvgConf(Tx* startTx, double& avg);
        void _getavgconf(Tx* currentTx, VpTx& visitedTx, int distance, double& avg);

        bool isPresent(std::string txID) const; //check if a transaction is already present in the myTangle vector
        Tx* attachTx(simtime_t attachTime, VpTx chosenTips); //creates a new transaction, then adds the new transaction to the tip

        Tx* updateTangle(const dataUpdate* data); //update the local tangle when a new transaction is received
        void updateMyTips(std::string tipID); //remove newly confirmed tips from myTips
        void updateMyBuffer(); //remove conflicted transaction from the buffer if founded

        void spreadTx(cModule* senderModule, dataUpdate* data); //broadcast to the neighbors modules the received transaction
        void broadcastTx(const Tx* newTx); //broadcast to the neighbors modules the issued transaction
        void spreadAuth(cModule* senderModule, dataAuth* data);
        void sendAuth(string hash, string IDRx, string IDTx);
        void sendASO(string data);
        void sendAuthReq(string IDRx, string IDTx);
        void sendAuthAck(string IDslave, string IDmaster);
        void spreadAso(cModule* senderModule, dataUpdateAso* data);
        void spreadAttacker(cModule* senderModule, dataAttacker* data, int aislado);
        void sendBlockReq(int index, int nonce, string data, string hash, string time, string prevHash, string destID);
        void callSendBlock(int newIndex, string dest);
        void sendNonce(int index, int nonce, string destID);
        string readTransaction(int transactionIndex);
        string getPassDinamic();
        string getTransactionData(int nTransaction);

        //Pass
        void setPassDict();
        std::vector<std::string> generateFromSeed(string seed);

        //Positions
        float calcularDistancia(string origenID, string destinoID);

        //PathLoss
        int loraTxPower = 14; //14dBm
        float loraTxFreq = 868; //MHz
        float calcularRxPower(int txPowerdBm, float freq, float distance);


        //Latency
        simtime_t timeIni, timeFin, timeLatency;

        //Attack
        void sendAuthAttack(string hash, string IDRx, string IDTx, int nAttack);
        void isolateAttacker();

        //free the used memory
        void deleteTangle();

        void _initialize(); //to call in the initialize() function from cSimpleModule
        void _finish(bool exportTangle, std::pair<bool,bool> exportTipsNumber); //to call in the finish() function from cSimpleModule

        //functions used when receiving a specified message type (in handleMessage()) 
        virtual void caseISSUE() = 0;
        virtual void casePOW(cMessage* msg) = 0;
        virtual void caseUPDATE(cMessage* msg) = 0;
        virtual void caseAUTH(cMessage* msg) = 0;
        virtual void caseBLOQ11() = 0;
        virtual void caseASO(cMessage* msg) = 0;
        virtual void caseASORESP(cMessage* msg) = 0;
        virtual void caseASOACK(cMessage* msg) = 0;
        virtual void caseUPDATEASO(cMessage* msg) = 0;
        virtual void caseATTACKER(cMessage* msg) = 0;
        virtual void updatePASS() = 0;
        virtual void startTx() = 0;
        virtual void caseSensorData(cMessage* msg) = 0;
        virtual void caseBlockChain(cMessage* msg) = 0;
        virtual void caseCompeteBlock(cMessage* msg) = 0;
        virtual void caseDataNonce(cMessage* msg) = 0;

        string negrita(string palabra);
        //Sensor Data
        void sendSensorData(dataSensor* data);
        void storeTransaction();
        int countNodeTrans = 0;
        std::vector<std::string> actualTransaction;
        std::vector<std::string> actualTransactionData;

        //Blockchain
        void BlockGenesis();
        int competeCounter = 0;
        string competeVec[2][4];

        void addBlockChain(int index, string data);
        void newBlock(string data, int index, int nNonce, string time);
        string mineBlock2(uint32_t nDifficulty, int nNonce, string sData, string tTime, int index, string sPrevHash);
        string calculateHash(int nIndex, string tTime, string sData, int nNonce, string sPrevHash);
        void updateBlock(int index, int nonce, string data, string hash, string time, string prevHash);

        int blockIndex = 1;
        bool firstBlock = true;

        //pesos
        int peso = 1;

        //SEECR
        int Qj = 0;
        int Qk = 0; // Paquetes in/out
        int X = 6; // Limite
        std::vector<std::string> attackerNodes; //Vector con IDs de nodos marcados como atacantes

        //block temporales
        int indexTemporal;
        int nonceTemporal;
        string dataTemporal;
        string hashTemporal;
        string timeTemporal;
        string prevHashTemporal;

        //tangle
        std::vector<std::string> tangleTable;
        std::vector<std::string> tangleTableInd;
        string nodoBSTA;

        //Hash pass
        string actualPassHash;
        string actualSaltHash;
        string pastSaltHash;
        bool firstPass = true;

        int txLimite = 3;
        int transCounter = 0;
        int passLimite = 0;
        string seedNodo0 = "cisco123456";
        string seedNodo1 = "cisco532145";
        string seedNodo2 = "passs123467";
        string seedNodo3 = "hola8765432";
        string seedNodo4 = "secret98765";
        string seedNodo5 = "contra24689";
        string seedNodo6 = "qwertyuiopa";
        string seedNodo7 = "zxcvbnmqwet";
        string seedNodo8 = "12345hjklbn";
        string seedNodo9 = "semilla9876";
        bool passInit = false;
        int passDictLength = 200;
        int saltDictLength = 50;

        // valores de corriente para sx1272 (mA)
        // https://semtech.my.salesforce.com/sfc/p/#E0000000JelG/a/440000001NCE/v_VBhk1IolDgxwwnOpcS_vTFxPfSEPQbuneK3mWsXlU
        float sx1272_sleep = 0.0001;
        float sx1272_tx = 18;
        float sx1272_rx = 11;
        //calculo de corriente
        float currentTotal = 0;
        float currentSleep = 0;
        float currentTx = 0;
        float currentRx = 0;


        //****** BSTA *******//
        int nIslas; //cantidad de islas
        int nbAttackerNode;
        int nDifficulty;
        std::string topology;

        //****** SENSORES*******//
        int countSensorTx;
        int maxSensorTx;

        //******* PATHLOSS ********//
        int pathLossExponent; //coeficiente
        int referenceDistance; //metros
        int referenceFreq; //MHz
        int referenceLoss_dB; //30dB de perdida a 1m

        float rxPowerSuma = 0;
        int numeroRx = 0;

        //******** PRUEBA ISLA CAIDA *********
        bool pruebaIslaCaida = false;

        //********* DOS *************
        int countDOS;

        //******* ISLAS CAIDAS **********
        bool islaCaida1;
        bool islaCaida2;
        bool islaCaida3;
        bool islaCaida4;

        //******** Vectores para record *******
        cOutVector rxPowerVector;
        cOutVector currentTxVector;
        cOutVector currentRxVector;

    protected:
        std::string ID; //the ID of the module
        int txCount; //counts the number of transactions issued by the module
        int txLimit; //how many transactions the module can issue (set in NED file)

        simtime_t rateMean; //exponential distribution with the given mean (set in the NED file)
        simtime_t powTime; //PoW time (set in NED file)

        cMessage* msgIssue; //to issue a new transaction
        cMessage* msgPoW; //to wait during the pow time
        cMessage* msgUpdate; //to send to others modules
        cMessage* msgAuth; //para autenticar en paso 1
        cMessage* msgBLOQ11;
        cMessage* msgASO;
        cMessage* msgAuthReq;
        cMessage* msgAuthAck;
        cMessage* msgUpdateAso;
        cMessage* msgUpdatePass;
        cMessage* msgAttacker;
        cMessage* msgSensorData;
        cMessage* msgStartTx;
        cMessage* msgDataBlock;
        cMessage* msgCompeteBlock;
        cMessage* msgDataNonce;
        cMessage* msgTimeOut;
        

        VpTx myTangle; //local Tangle
        VpTx myTips; //keep a record of all the current unapproved transactions
        std::vector<std::string> myBuffer; //a buffer for all conflicted transaction to be checked  
};
