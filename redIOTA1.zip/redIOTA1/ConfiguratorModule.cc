#include "ConfiguratorModule.h"
#include <iostream>

std::vector<int> ConfiguratorModule::split(const std::string& line) const
{
    std::vector<int> tokens;
    std::string token;
    std::istringstream tokenStream(line);

    while(std::getline(tokenStream, token, ','))
    {
        tokens.push_back(stoi(token));
    }

    return tokens;
}

std::map<int,std::vector<int>> ConfiguratorModule::getEdgeList() const
{
    std::string currentTopo = getParentModule()->par("topology");
    //std::cout << "**************** TOPO: " << currentTopo << "\n";
    EV << "*** Topolgia actual: " << currentTopo << " parent: " << getParentModule() << "\n";
    std::string path = "./topologies/CSV/" + currentTopo + ".csv";
    std::fstream file;
    file.open(path,std::ios::in);

    if(!file.is_open()) throw std::runtime_error("Could not open CSV file");

    std::string line;
    std::map<int,std::vector<int>> myTopo;

    while(getline(file,line))
    {
        auto edgeList = split(line);
        myTopo[edgeList[0]] = std::vector<int>(edgeList.begin() + 1, edgeList.begin() + edgeList.size());
    }

    file.close();

    return myTopo;
}

void ConfiguratorModule::connectModules(cModule* moduleOut, cModule* moduleIn)
{
    double delay = 0.0;

    if(getParentModule()->par("ifRandDelay"))
    {
       double minDelay = getParentModule()->par("minDelay");
       double maxDelay = getParentModule()->par("maxDelay");
       delay = uniform(minDelay,maxDelay);
    }

    else
    {
       delay = getParentModule()->par("delay");
    }

    auto channel = cDelayChannel::create("Channel");

    channel->setDelay(delay);


    moduleOut->setGateSize("out",moduleOut->gateSize("out") + 1);
    moduleIn->setGateSize("in",moduleIn->gateSize("in") + 1);

    auto gOut = moduleOut->gate("out",moduleOut->gateSize("out") - 1);
    auto gIn = moduleIn->gate("in",moduleIn->gateSize("in") - 1);

    //EV << "confModule-getDisplayString: " << moduleOut->getDisplayString().str() << endl;

    gOut->connectTo(gIn,channel);
    gOut->getChannel()->callInitialize();

    /*
    cDisplayString & disp = gOut->getDisplayString();
    disp.setTagArg("ls", 1, "0"); // 1 indicates argument of the Tag, 0 - width
    */
    //conexiones entre gates no son visibles (width=0)
    gOut->getDisplayString().setTagArg("ls",1,"0");
}

//posiciones
void ConfiguratorModule::positionModules(cModule* moduleOut, int edgeFirst)
{

    //Posiciones
    int posX, posY, currentTopoInt;

    std::string currentTopo = getParentModule()->par("topology");
    if (currentTopo == "UnaIsla") currentTopoInt = 0;
    else if (currentTopo == "SinAtaques") currentTopoInt = 1;
    else if (currentTopo == "ConAtaques") currentTopoInt = 2;
    else if (currentTopo == "IslaAumentada") currentTopoInt = 3;
    else if (currentTopo == "NodosAumentados") currentTopoInt = 4;

    //Corrige el tama�o del background acorde a la topologia
    if (currentTopoInt == 0) {
        getParentModule()->getDisplayString().setTagArg("bgb",0,1100);
        getParentModule()->getDisplayString().setTagArg("bgb",1,700);
    }
    else if (currentTopoInt <= 2) {
        getParentModule()->getDisplayString().setTagArg("bgb",0,2000);
        getParentModule()->getDisplayString().setTagArg("bgb",1,1500);
    } else if (currentTopoInt == 3) {
        getParentModule()->getDisplayString().setTagArg("bgb",0,2100);
        getParentModule()->getDisplayString().setTagArg("bgb",1,2500);
    }


    switch(currentTopoInt)
    {
    case 0:
        switch(edgeFirst)
        {
        case 0:
            posY = 300;
            posX = 200;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 1]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 1:
            posY = 500;
            posX = 300;
            break;
        case 2:
            posY = 100;
            posX = 300;
            break;
        case 3:
            posY = 100;
            posX = 500;
            break;
        case 4:
            posY = 500;
            posX = 500;
            break;
        case 5:
            posY = 100;
            posX = 700;
            break;
        case 6:
            posY = 300;
            posX = 700;
            break;
        case 7:
            posY = 500;
            posX = 700;
            break;
        case 8:
            posY = 200;
            posX = 900;
            break;
        case 9:
            posY = 400;
            posX = 900;
            break;
        }
        break;

    case 1:
        switch(edgeFirst)
        {
        case 0:
            posY = 300;
            posX = 1000;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 1]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 1:
            posY = 500;
            posX = 1100;
            break;
        case 2:
            posY = 100;
            posX = 1100;
            break;
        case 3:
            posY = 100;
            posX = 1300;
            break;
        case 4:
            posY = 500;
            posX = 1300;
            break;
        case 5:
            posY = 100;
            posX = 1500;
            break;
        case 6:
            posY = 300;
            posX = 1500;
            break;
        case 7:
            posY = 500;
            posX = 1500;
            break;
        case 8:
            posY = 200;
            posX = 1700;
            break;
        case 9:
            posY = 400;
            posX = 1700;
            break;
        //Nodos Blockchain
        case 10:
            posY = 300;
            posX = 800;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 2]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 11:
            posY = 500;
            posX = 700;
            break;
        case 12:
            posY = 100;
            posX = 700;
            break;
        case 13:
            posY = 100;
            posX = 500;
            break;
        case 14:
            posY = 500;
            posX = 500;
            break;
        case 15:
            posY = 100;
            posX = 300;
            break;
        case 16:
            posY = 300;
            posX = 300;
            break;
        case 17:
            posY = 500;
            posX = 300;
            break;
        case 18:
            posY = 200;
            posX = 100;
            break;
        case 19:
            posY = 400;
            posX = 100;
            break;
        case 20:
            posY = 700;
            posX = 900;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 3]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 21:
            posX = 1200;
            posY = 800;
            break;
        case 22:
            posX = 600;
            posY = 800;
            break;
        case 23:
            posX = 600;
            posY = 1000;
            break;
        case 24:
            posX = 1200;
            posY = 1000;
            break;
        case 25:
            posX = 600;
            posY = 1200;
            break;
        case 26:
            posX = 900;
            posY = 1200;
            break;
        case 27:
            posX = 1200;
            posY = 1200;
            break;
        case 28:
            posX = 700;
            posY = 1400;
            break;
        case 29:
            posX = 1100;
            posY = 1400;
            break;
        }
        break;

    case 2:
        switch(edgeFirst)
        {
        case 0:
            posY = 300;
            posX = 1000;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 1]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 1:
            posY = 500;
            posX = 1100;
            break;
        case 2:
            posY = 100;
            posX = 1100;
            break;
        case 3:
            posY = 100;
            posX = 1300;
            break;
        case 4:
            posY = 500;
            posX = 1300;
            break;
        case 5:
            posY = 100;
            posX = 1500;
            break;
        case 6:
            posY = 300;
            posX = 1500;
            break;
        case 7:
            posY = 500;
            posX = 1500;
            break;
        case 8:
            posY = 200;
            posX = 1700;
            break;
        case 9:
            posY = 400;
            posX = 1700;
            break;
        //Nodos Blockchain
        case 10:
            posY = 300;
            posX = 800;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 2]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 11:
            posY = 500;
            posX = 700;
            break;
        case 12:
            posY = 100;
            posX = 700;
            break;
        case 13:
            posY = 100;
            posX = 500;
            break;
        case 14:
            posY = 500;
            posX = 500;
            break;
        case 15:
            posY = 100;
            posX = 300;
            break;
        case 16:
            posY = 300;
            posX = 300;
            break;
        case 17:
            posY = 500;
            posX = 300;
            break;
        case 18:
            posY = 200;
            posX = 100;
            break;
        case 19:
            posY = 400;
            posX = 100;
            break;
        case 20:
            posY = 700;
            posX = 900;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 3]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 21:
            posX = 1200;
            posY = 800;
            break;
        case 22:
            posX = 600;
            posY = 800;
            break;
        case 23:
            posX = 600;
            posY = 1000;
            break;
        case 24:
            posX = 1200;
            posY = 1000;
            break;
        case 25:
            posX = 600;
            posY = 1200;
            break;
        case 26:
            posX = 900;
            posY = 1200;
            break;
        case 27:
            posX = 1200;
            posY = 1200;
            break;
        case 28:
            posX = 700;
            posY = 1400;
            break;
        case 29:
            posX = 1100;
            posY = 1400;
            break;
        //Atacante
        case 30:
            posX = 1500;
            posY = 700;
            moduleOut->getDisplayString().setTagArg("t", 0, "Atacante [99]");
            break;
        case 31:
            posX = 1700;
            posY = 100;
            moduleOut->getDisplayString().setTagArg("t", 0, "Atacante [100]");
            break;
        }
        break;

    case 3:
        switch(edgeFirst)
        {
        case 0:
            posY = 300;
            posX = 1000;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 1]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            //i=device/card,green,10;is=l
            break;
        case 1:
            posY = 500;
            posX = 1100;
            break;
        case 2:
            posY = 100;
            posX = 1100;
            break;
        case 3:
            posY = 100;
            posX = 1300;
            break;
        case 4:
            posY = 500;
            posX = 1300;
            break;
        case 5:
            posY = 100;
            posX = 1500;
            break;
        case 6:
            posY = 300;
            posX = 1500;
            break;
        case 7:
            posY = 500;
            posX = 1500;
            break;
        case 8:
            posY = 200;
            posX = 1700;
            break;
        case 9:
            posY = 400;
            posX = 1700;
            break;
        //Nodos Blockchain
        case 10:
            posY = 300;
            posX = 800;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 2]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 11:
            posY = 500;
            posX = 700;
            break;
        case 12:
            posY = 100;
            posX = 700;
            break;
        case 13:
            posY = 100;
            posX = 500;
            break;
        case 14:
            posY = 500;
            posX = 500;
            break;
        case 15:
            posY = 100;
            posX = 300;
            break;
        case 16:
            posY = 300;
            posX = 300;
            break;
        case 17:
            posY = 500;
            posX = 300;
            break;
        case 18:
            posY = 200;
            posX = 100;
            break;
        case 19:
            posY = 400;
            posX = 100;
            break;
        case 20:
            posY = 700;
            posX = 900;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 3]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 21:
            posX = 1200;
            posY = 800;
            break;
        case 22:
            posX = 600;
            posY = 800;
            break;
        case 23:
            posX = 600;
            posY = 1000;
            break;
        case 24:
            posX = 1200;
            posY = 1000;
            break;
        case 25:
            posX = 600;
            posY = 1200;
            break;
        case 26:
            posX = 900;
            posY = 1200;
            break;
        case 27:
            posX = 1200;
            posY = 1200;
            break;
        case 28:
            posX = 700;
            posY = 1400;
            break;
        case 29:
            posX = 1100;
            posY = 1400;
            break;
        case 30:
            posX = 900;
            posY = -100;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 4]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 31:
            posX = 1200;
            posY = -200;
            break;
        case 32:
            posX = 600;
            posY = -200;
            break;
        case 33:
            posX = 600;
            posY = -400;
            break;
        case 34:
            posX = 1200;
            posY = -400;
            break;
        case 35:
            posX = 600;
            posY = -600;
            break;
        case 36:
            posX = 900;
            posY = -600;
            break;
        case 37:
            posX = 1200;
            posY = -600;
            break;
        case 38:
            posX = 700;
            posY = -800;
            break;
        case 39:
            posX = 1200;
            posY = -800;
            break;
        //Atacante
        case 40:
            posX = 1500;
            posY = 700;
            moduleOut->getDisplayString().setTagArg("t", 0, "Atacante [99]");
            break;
        case 41:
            posX = 1900;
            posY = 200;
            moduleOut->getDisplayString().setTagArg("t", 0, "Atacante [100]");
            break;
        }
        break;

    case 4:
        switch(edgeFirst)
        {
        case 0:
            posY = 300;
            posX = 1000;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 1]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 1:
            posY = 500;
            posX = 1100;
            break;
        case 2:
            posY = 100;
            posX = 1100;
            break;
        case 3:
            posY = 100;
            posX = 1300;
            break;
        case 4:
            posY = 500;
            posX = 1300;
            break;
        case 5:
            posY = 100;
            posX = 1500;
            break;
        case 6:
            posY = 300;
            posX = 1500;
            break;
        case 7:
            posY = 500;
            posX = 1500;
            break;
        case 8:
            posY = 200;
            posX = 1700;
            break;
        case 9:
            posY = 400;
            posX = 1700;
            break;
        //Nodos Blockchain
        case 10:
            posY = 300;
            posX = 800;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 2]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 11:
            posY = 500;
            posX = 700;
            break;
        case 12:
            posY = 100;
            posX = 700;
            break;
        case 13:
            posY = 100;
            posX = 500;
            break;
        case 14:
            posY = 500;
            posX = 500;
            break;
        case 15:
            posY = 100;
            posX = 300;
            break;
        case 16:
            posY = 300;
            posX = 300;
            break;
        case 17:
            posY = 500;
            posX = 300;
            break;
        case 18:
            posY = 200;
            posX = 100;
            break;
        case 19:
            posY = 400;
            posX = 100;
            break;
        case 20:
            posY = 700;
            posX = 900;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 3]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 21:
            posX = 1200;
            posY = 800;
            break;
        case 22:
            posX = 600;
            posY = 800;
            break;
        case 23:
            posX = 600;
            posY = 1000;
            break;
        case 24:
            posX = 1200;
            posY = 1000;
            break;
        case 25:
            posX = 600;
            posY = 1200;
            break;
        case 26:
            posX = 900;
            posY = 1200;
            break;
        case 27:
            posX = 1200;
            posY = 1200;
            break;
        case 28:
            posX = 700;
            posY = 1400;
            break;
        case 29:
            posX = 1100;
            posY = 1400;
            break;
        case 30:
            posX = 900;
            posY = -100;
            moduleOut->getDisplayString().setTagArg("t", 0, "[Isla 4]");
            moduleOut->getDisplayString().setTagArg("i", 0, "device/antennatower");
            break;
        case 31:
            posX = 1200;
            posY = -200;
            break;
        case 32:
            posX = 600;
            posY = -200;
            break;
        case 33:
            posX = 600;
            posY = -400;
            break;
        case 34:
            posX = 1200;
            posY = -400;
            break;
        case 35:
            posX = 600;
            posY = -600;
            break;
        case 36:
            posX = 900;
            posY = -600;
            break;
        case 37:
            posX = 1200;
            posY = -600;
            break;
        case 38:
            posX = 700;
            posY = -800;
            break;
        case 39:
            posX = 1100;
            posY = -800;
            break;
        //Atacante
        case 50:
            posX = 1500;
            posY = 700;
            moduleOut->getDisplayString().setTagArg("t", 0, "Atacante [99]");
            break;
        case 51:
            posX = 1700;
            posY = 100;
            moduleOut->getDisplayString().setTagArg("t", 0, "Atacante [100]");
            break;
        //Isla extendida
        case 40:
            posX = 1900;
            posY = 100;
            break;
        case 41:
            posX = 1900;
            posY = 300;
            break;
        case 42:
            posX = 1900;
            posY = 500;
            break;
        case 43:
            posX = 2100;
            posY = 100;
            break;
        case 44:
            posX = 2100;
            posY = 300;
            break;
        case 45:
            posX = 2100;
            posY = 500;
            break;
        case 46:
            posX = 2300;
            posY = 0;
            break;
        case 47:
            posX = 2300;
            posY = 200;
            break;
        case 48:
            posX = 2300;
            posY = 400;
            break;
        case 49:
            posX = 2300;
            posY = 600;
            break;
        }
        break;
    }

    moduleOut->getDisplayString().setTagArg("p",0,posX);
    if (currentTopoInt > 2) moduleOut->getDisplayString().setTagArg("p", 1, posY + 1000);
    else moduleOut->getDisplayString().setTagArg("p", 1, posY);

    positionsVec.push_back("[" + std::to_string(edgeFirst) + "];" + std::to_string(posX) + ";" + std::to_string(posY));

    int edgeLimit = getParentModule()->par("nbHonestNode");

    if (edgeFirst == (edgeLimit + 1)) {
        //Almacena en un CSV la posicion actual del nodo
        std::fstream file;
        std::string path = "./data/positions.csv";
        remove(path.c_str());
        file.open(path,std::ios::app);
        for (auto piece: positionsVec) {
            file << piece << ";\n";
        }
        file.close();
    }

    //moduleOut->getDisplayString().setTagArg("t", 0, "Nodo");
    //moduleOut->getDisplayString().setTagArg("tt", 0, "moduleOut");

}

std::vector<cModule*> ConfiguratorModule::getModules() const
{
    std::vector<cModule*> myModules;
    int nbMaliciousNode = getParentModule()->par("nbMaliciousNode");
    int nbHonestNode = getParentModule()->par("nbHonestNode");



    for(int i = 0; i < nbHonestNode; i++)
    {
        myModules.push_back(getParentModule()->getSubmodule("Honest",i));
        //EV << "confModule::myModulesPushBack: " << getParentModule()->getSubmodule("Honest",i) << std::endl;
    }

    for(int i = 0; i < nbMaliciousNode; i++)
    {
        myModules.push_back(getParentModule()->getSubmodule("Malicious",i));
        //EV << "confModule::myModulesPushBack: " << getParentModule()->getSubmodule("Malicious",i) << std::endl;
    }

    return myModules;
}

void ConfiguratorModule::checkError(int nodeID, int totalModules) const
{
    bool islaCaida1 = getParentModule()->par("islaCaida1");
    bool islaCaida2 = getParentModule()->par("islaCaida2");
    bool islaCaida3 = getParentModule()->par("islaCaida3");
    bool islaCaida4 = getParentModule()->par("islaCaida4");
    int nIslasCaidas = 0;

    if (islaCaida1) nIslasCaidas++;
    if (islaCaida2) nIslasCaidas++;
    if (islaCaida3) nIslasCaidas++;
    if (islaCaida4) nIslasCaidas++;

    std::string actualTopo = getParentModule()->par("topology");
    if (actualTopo == "UnaIsla") {
        if (nIslasCaidas >= 1) throw cRuntimeError("Numero de islas caidas no permitido! Revise el archivo ini");
    } else if (actualTopo == "ConAtaques" || actualTopo == "SinAtaques") {
        if (nIslasCaidas >= 2) throw cRuntimeError("Numero de islas caidas no permitido! Revise el archivo ini");
    } else {
        if (nIslasCaidas >= 3) throw cRuntimeError("Numero de islas caidas no permitido! Revise el archivo ini");
    }

    if(nodeID < 0 || nodeID >= totalModules)
    {
        throw std::runtime_error("La cantidad de modulos configurados no es correcta, revise el archivo .ned por defecto o el .ini para cambios!");
    }
}

void ConfiguratorModule::initialize()
{
    EV << "Configurando conexiones:" << std::endl;

    auto myTopo = getEdgeList();
    auto myModules = getModules();

    for(auto const edge : myTopo)
    {
        checkError(edge.first,myModules.size());
        auto moduleOut = myModules[edge.first];

        //Cambiar posisiciones de los nodos
        positionModules(moduleOut,edge.first);

        for(int idx : edge.second)
        {
            checkError(idx,myModules.size());
            auto moduleIn = myModules[idx];
            connectModules(moduleOut,moduleIn);
            EV << "Module " << moduleOut->getId() - 3 << " ---> Module " << moduleIn->getId() - 3 << std::endl;
        }
    }
}
