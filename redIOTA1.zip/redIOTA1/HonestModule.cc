#include "HonestModule.h"
#include <stdio.h>

using std::string;


void HonestModule::caseISSUE()
{
    if(txCount <= txLimit)
    {
        auto chosenTips = getTipsTSA();

        if(chosenTips.empty())
        {
            EV << "The TSA did not give legit tips to approve: attempting again\n";
            scheduleAt(simTime() + exponential(rateMean), msgIssue);
            return;
        }

        EV << "Chosen Tips: ";

        for(const auto tip : chosenTips) EV << tip->ID << " "; EV << "\nPow time: "  << chosenTips.size() * powTime << "\n";

        msgPoW->setContextPointer(&chosenTips);

        if(powTime == 0.0)
        {
            EV << "POW=0.0 sizeTips-> " << chosenTips.size() << "\n";
            casePOW(msgPoW);
        }

        else
        {
            //casePOW(msgPoW);
            scheduleAt(simTime() + chosenTips.size() * powTime, msgPoW);
            //EV << "INFO POWTime != 0: shcheduleAt-> " << simTime() + chosenTips.size() * powTime << "; size*PowTime: " << chosenTips.size() * powTime << "\n";
        }
    }

    else
    {
        EV << "Number of transactions reached: stopping issuing\n";
    }
}

void HonestModule::casePOW(cMessage* msg)
{
    //EV << "HonestModule::casePOW \n";
    auto chosenTips = (VpTx*) msg->getContextPointer();
    //EV << "DEBUG 1: msg-> "<< msg->getFullName() << "\n";
    //EV << "DEBUG 1.5: simTime-> "<< simTime() << " chosenTips-> "<< chosenTips << " \n";
    auto newTx = attachTx(simTime(),*chosenTips);
    //EV << "DEBUG 2: simTime-> "<< simTime() << " chosenTips-> "<< chosenTips << " \n";

    EV << "Pow time finished for " << newTx->ID << ", sending it to all nodes\n";
    
    broadcastTx(newTx);
    //EV << "DEBUG 3 \n";

    //scheduleAt(simTime() + 2.00, msgIssue);
    scheduleAt(simTime() + exponential(rateMean), msgIssue);
    //EV << "DEBUG 4 \n";
    //EV << "INFO nextIssue != 0: scheduleAt-> " << simTime() + exponential(rateMean) << "\n";
}

void HonestModule::caseUPDATE(cMessage* msg)
{
    auto data =  (dataUpdate*) msg->getContextPointer();

    if(isPresent(data->ID))
    {
        EV << "Transaction " << data->ID << " is already present\n";
        delete data;
        delete msg;
        return;
    }

    EV << "Received a new transaction " << data->ID << "\n";

    bubble("Nueva transaccion!");
    updateTangle(data);
    updateMyBuffer();
    spreadTx(msg->getSenderModule(),data);
    
    delete data;
    delete msg; 
}




void HonestModule::powHash(string passHash, string IDRx, string IDTx)
{
    EV << "Proceso de autenticacion..." << endl;
    //auto data = (dataAuth*) msg->getContextPointer();

    // Leer diccionario de pass
    std::string path = "./data/passDict.csv";
    std::fstream file;
    file.open(path,std::ios::in);

    if(!file.is_open()) throw std::runtime_error("Could not open CSV file");
    std::string line;

    string input1, output1;
    //string passHash = "e73b79a0b10f8cdb6ac7dbe4c0a5e25776e1148784b86cf98f7d6719d472af69";

    while(getline(file,line))
    {
        input1 = line;
        output1 = checkSalt(input1, passHash);

        if (sha256(input1 + output1) == passHash)
        {
            sendAuth(sha256(output1), IDRx, IDTx);
            break;
        }
    }
    file.close();

    //forzado
    //sendAuth(passHash, IDRx, IDTx);
}

string HonestModule::checkSalt(string pass, string passHash){
    // Leer diccionario de salt
    std::string path1 = "./data/salDict.csv";
    std::fstream file1;
    file1.open(path1,std::ios::in);

    if(!file1.is_open()) throw std::runtime_error("Could not open CSV file");
    std::string line1;

    int i = 1;
    string input1, input2, output1;

    input1 = pass;

    while(getline(file1,line1))
    {
        input2 = line1;
        //EV << "pass: " << input1 << " salt: " << input2 << endl;
        output1 = input1 + input2;
        //EV << "pass + salt: " << sha256(output1) << " hash: " << passHash << endl;
        if (sha256(output1) == passHash)
        {
            EV << "Hash encontrado en el intento: " << i << "\nEnviando salt hacia el nodo para validacion " << endl;
            EV << "Pass: " << input1 << "\nSalt: " << input2 << endl;
            break;
        }
        i++;
    }
    file1.close();

    return input2;
}

//################################################################################################################################
//####################################################    INICIO    ##############################################################
//################################################################################################################################

void HonestModule::caseBLOQ11()
{
    // ISLA 1
    if (!nodo1Aso && ID == "[1]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[2]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[3]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[4]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[5]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[6]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[7]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[8]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[9]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[40]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[41]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[42]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[43]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[44]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[45]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[46]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[47]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[48]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo1Aso && !nodoActAso && ID == "[49]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }


    // ISLA 2
    if (!nodo11Aso && ID == "[11]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[12]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[13]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[14]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[15]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[16]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[17]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[18]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo11Aso && !nodoActAso && ID == "[19]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }


    // ISLA 3
    if (!nodo21Aso && ID == "[21]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[22]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[23]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[24]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[25]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[26]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[27]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[28]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo21Aso && !nodoActAso && ID == "[29]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }

    // ISLA 4
    if (!nodo31Aso && ID == "[31]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[32]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[33]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[34]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[35]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[36]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[37]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[38]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }
    if (nodo31Aso && !nodoActAso && ID == "[39]")
    {
        EV << "Nodo " << ID << " envia peticion de asosiacion!" << endl;
        sendASO(ID);
        nodoActAso = true;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }

    timeIni = simTime();
    EV << "****** timeIni: " << timeIni << endl;
}

void HonestModule::updatePASS()
{
    if (passLimite <= txLimite)
    {
        if(firstPass == false){
            pastSaltHash = actualSaltHash;
            EV << "****PastSaltHash: " << pastSaltHash << endl;

            //Proceso de asignar BSTA
            if (ID == "[1]" || ID == "[2]" || ID == "[3]" || ID == "[4]" || ID == "[5]" || ID == "[6]" || ID == "[7]" || ID == "[8]" || ID == "[9]" || ID == "[40]" || ID == "[41]" || ID == "[42]" || ID == "[43]" || ID == "[44]" || ID == "[45]" || ID == "[46]" || ID == "[47]" || ID == "[48]" || ID == "[49]") {
                nodoBSTA = "[0]";
            } else if (ID == "[11]" || ID == "[12]" || ID == "[13]" || ID == "[14]" || ID == "[15]" || ID == "[16]" || ID == "[17]" || ID == "[18]" || ID == "[19]") {
                nodoBSTA = "[10]";
            } else if (ID == "[21]" || ID == "[22]" || ID == "[23]" || ID == "[24]" || ID == "[25]" || ID == "[26]" || ID == "[27]" || ID == "[28]" || ID == "[29]") {
                nodoBSTA = "[20]";
            } else if (ID == "[31]" || ID == "[32]" || ID == "[33]" || ID == "[34]" || ID == "[35]" || ID == "[36]" || ID == "[37]" || ID == "[38]" || ID == "[39]") {
                nodoBSTA = "[30]";
            }
        }
        actualPassHash = getPassDinamic();
        firstPass = false;

        scheduleAt(simTime() + 5 - peso*0.01, msgUpdatePass);
        EV << "Siguiente actualizacion en t= " << simTime() + 5 - peso*0.1 << " (s)."  << endl;
        passLimite++;
        currentSleep += sx1272_sleep;

    } else {
        EV << "Actualizaciones de pass terminadas..." << endl;
    }
}

void HonestModule::marcarAtacante(string nodoID, cMessage* msg){
    //Agrega a su propia lista de marcados
    if (std::find(attackerNodes.begin(), attackerNodes.end(), ID + nodoID) != attackerNodes.end())
    {
        EV << "Nodo atacante ya registrado!" << endl;
    } else {
        attackerNodes.push_back(ID + nodoID);
    }

    EV << "Enviando la ID del nodo marcado a todos los nodos..." << endl;
    auto copyData = new dataAttacker;
    copyData->IDattacker = nodoID; //Nodo atacante
    copyData->ID = ID; //Nodo que lo marca

    spreadAttacker(msg->getSenderModule(), copyData, 1);

    EV << "Aislando al nodo marcado!" << endl;
    isolateAttacker();
}

void HonestModule::SEECR(string nodoID, int indexIO, cMessage* msg){
    if(std::find(controlIDvec.begin(), controlIDvec.end(), nodoID) != controlIDvec.end()) {
        EV << "Nodo " << nodoID << " ya registrado en el vector de control!" << endl;
        //std::cout << "Nodo " << nodoID << " ya registrado en el vector de control!" << endl;
    }
    else {
        EV << "Registrando nodo " << nodoID << " en el vector de control!" << endl;
        //std::cout << "Registrando nodo " << nodoID << " en el vector de control!" << endl;
        controlIDvec.push_back(nodoID);
        controlIndVec.push_back({ 0 , 0 });
    }

    int indVec = std::find(controlIDvec.begin(), controlIDvec.end(), nodoID) - controlIDvec.begin(); //Se obtiene el index del nodo registrado
    //std::cout << "Indice: " << indVec << endl;
    controlIndVec[indVec][indexIO] += 1;

    EV << "Nodo " << ID << " actualiza los valores de \x1b[1m\x1b[34mQj: " << controlIndVec[indVec][0] << " \x1b[0my \x1b[1m\x1b[31mQk: " << controlIndVec[indVec][1] << " \x1b[0mpara el nodo " << nodoID << endl;
    if ((controlIndVec[indVec][1] - controlIndVec[indVec][0]) > 8) {
        EV << "El nodo " << nodoID << " ha sido marcado como atacante!" << endl;
        marcarAtacante(nodoID, msg);
    }
}

void HonestModule::caseASO(cMessage* msg){

    auto data = (dataASO*) msg->getContextPointer();
    bool validID = false;

    // ISLA 1
    //Responde a todos los conectados
    if(ID == "[0]")
    {
        validID = true;
    }
    //Responde a todos los conectados
    if(ID == "[1]")
    {
        validID = true;
    }
    //Respuesta a nodo [3]
    if(ID == "[2]" && data->ID == "[3]")
    {
        validID = true;
    }
    //Respuesta a nodo [4]
    if(ID == "[3]" && data->ID == "[4]")
    {
        validID = true;
    }
    //Respuesta a nodo [5]
    if(ID == "[6]" && data->ID == "[5]")
    {
        validID = true;
    }
    //Respuesta a nodo [6]
    if(ID == "[3]" && data->ID == "[6]")
    {
        validID = true;
    }
    if(ID == "[4]" && data->ID == "[6]")
    {
        validID = true;
    }
    //Respuesta a nodo [7]
    if(ID == "[4]" && data->ID == "[7]")
    {
        validID = true;
    }
    if(ID == "[6]" && data->ID == "[7]")
    {
        validID = true;
    }
    //Respuesta a nodo [8]
    if(ID == "[5]" && data->ID == "[8]")
    {
        validID = true;
    }
    if(ID == "[6]" && data->ID == "[8]")
    {
        validID = true;
    }
    //Respuesta a nodo [9]
    if(ID == "[6]" && data->ID == "[9]")
    {
        validID = true;
    }
    if(ID == "[7]" && data->ID == "[9]")
    {
        validID = true;
    }
    //Respuesta a nodo [40]
    if((ID == "[8]" || ID == "[9]") && data->ID == "[40]")
    {
        validID = true;
    }
    //Respuesta a nodo [41]
    if((ID == "[9]" || ID == "[40]") && data->ID == "[41]")
    {
        validID = true;
    }
    //Respuesta a nodo [42]
    if((ID == "[40]" || ID == "[41]") && data->ID == "[42]")
    {
        validID = true;
    }
    //Respuesta a nodo [43]
    if((ID == "[41]" || ID == "[42]") && data->ID == "[43]")
    {
        validID = true;
    }
    //Respuesta a nodo [44]
    if((ID == "[42]" || ID == "[43]") && data->ID == "[44]")
    {
        validID = true;
    }
    //Respuesta a nodo [45]
    if((ID == "[43]" || ID == "[44]") && data->ID == "[45]")
    {
        validID = true;
    }
    //Respuesta a nodo [46]
    if((ID == "[44]" || ID == "[45]") && data->ID == "[46]")
    {
        validID = true;
    }
    //Respuesta a nodo [47]
    if((ID == "[45]" || ID == "[46]") && data->ID == "[47]")
    {
        validID = true;
    }
    //Respuesta a nodo [48]
    if((ID == "[46]" || ID == "[47]") && data->ID == "[48]")
    {
       validID = true;
    }
    //Respuesta a nodo [49]
    if((ID == "[47]" || ID == "[48]") && data->ID == "[49]")
    {
       validID = true;
    }


    // ISLA 2
    //Responde a todos los conectados
    if(ID == "[10]")
    {
        validID = true;
    }
    //Responde a todos los conectados
    if(ID == "[11]")
    {
        validID = true;
    }
    //Respuesta a nodo [3]
    if(ID == "[12]" && data->ID == "[13]")
    {
        validID = true;
    }
    //Respuesta a nodo [4]
    if(ID == "[13]" && data->ID == "[14]")
    {
        validID = true;
    }
    //Respuesta a nodo [5]
    if(ID == "[16]" && data->ID == "[15]")
    {
        validID = true;
    }
    //Respuesta a nodo [6]
    if(ID == "[13]" && data->ID == "[16]")
    {
        validID = true;
    }
    if(ID == "[14]" && data->ID == "[16]")
    {
        validID = true;
    }
    //Respuesta a nodo [7]
    if(ID == "[14]" && data->ID == "[17]")
    {
        validID = true;
    }
    if(ID == "[16]" && data->ID == "[17]")
    {
        validID = true;
    }
    //Respuesta a nodo [8]
    if(ID == "[15]" && data->ID == "[18]")
    {
        validID = true;
    }
    if(ID == "[16]" && data->ID == "[18]")
    {
        validID = true;
    }
    //Respuesta a nodo [9]
    if(ID == "[16]" && data->ID == "[19]")
    {
        validID = true;
    }
    if(ID == "[17]" && data->ID == "[19]")
    {
        validID = true;
    }


    // ISLA 3
    //Responde a todos los conectados
    if(ID == "[20]")
    {
        validID = true;
    }
    //Responde a todos los conectados
    if(ID == "[21]")
    {
        validID = true;
    }
    //Respuesta a nodo [3]
    if(ID == "[22]" && data->ID == "[23]")
    {
        validID = true;
    }
    //Respuesta a nodo [4]
    if(ID == "[23]" && data->ID == "[24]")
    {
        validID = true;
    }
    //Respuesta a nodo [5]
    if(ID == "[26]" && data->ID == "[25]")
    {
        validID = true;
    }
    //Respuesta a nodo [6]
    if(ID == "[23]" && data->ID == "[26]")
    {
        validID = true;
    }
    if(ID == "[24]" && data->ID == "[26]")
    {
        validID = true;
    }
    //Respuesta a nodo [7]
    if(ID == "[24]" && data->ID == "[27]")
    {
        validID = true;
    }
    if(ID == "[26]" && data->ID == "[27]")
    {
        validID = true;
    }
    //Respuesta a nodo [8]
    if(ID == "[25]" && data->ID == "[28]")
    {
        validID = true;
    }
    if(ID == "[26]" && data->ID == "[28]")
    {
        validID = true;
    }
    //Respuesta a nodo [9]
    if(ID == "[26]" && data->ID == "[29]")
    {
        validID = true;
    }
    if(ID == "[27]" && data->ID == "[29]")
    {
        validID = true;
    }

    // ISLA 4
    //Responde a todos los conectados
    if(ID == "[30]")
    {
        validID = true;
    }
    //Responde a todos los conectados
    if(ID == "[31]")
    {
        validID = true;
    }
    //Respuesta a nodo [3]
    if(ID == "[32]" && data->ID == "[33]")
    {
        validID = true;
    }
    //Respuesta a nodo [4]
    if(ID == "[33]" && data->ID == "[34]")
    {
        validID = true;
    }
    //Respuesta a nodo [5]
    if(ID == "[36]" && data->ID == "[35]")
    {
        validID = true;
    }
    //Respuesta a nodo [6]
    if(ID == "[33]" && data->ID == "[36]")
    {
        validID = true;
    }
    if(ID == "[34]" && data->ID == "[36]")
    {
        validID = true;
    }
    //Respuesta a nodo [7]
    if(ID == "[34]" && data->ID == "[37]")
    {
        validID = true;
    }
    if(ID == "[36]" && data->ID == "[37]")
    {
        validID = true;
    }
    //Respuesta a nodo [8]
    if(ID == "[35]" && data->ID == "[38]")
    {
        validID = true;
    }
    if(ID == "[36]" && data->ID == "[38]")
    {
        validID = true;
    }
    //Respuesta a nodo [9]
    if(ID == "[36]" && data->ID == "[39]")
    {
        validID = true;
    }
    if(ID == "[37]" && data->ID == "[39]")
    {
        validID = true;
    }


    //Ataque
    if(ID == "[4]"  && data->ID == "[99]")
    {
        validID = true;
    }
    if(ID == "[7]"  && data->ID == "[99]")
    {
        validID = true;
    }
    if(ID == "[9]"  && data->ID == "[99]")
    {
        validID = true;
    }


    if (validID)
    {
        bubble("Recibida ASO!");
        EV << "RECIBIDO MSG_ASO con ID: " << data->ID << endl;
        if (ID == "[0]" || ID == "[10]" || ID == "[20]" || ID == "[30]") EV << "Enviando hash para PoW: " << actualPassHash << "\nhacia el nodo " << data->ID << "; desde la BSTA " << ID << endl;
        else EV << "Enviando hash para PoW: " << actualPassHash << "\nhacia el nodo " << data->ID << "; desde el nodo " << ID << endl;
        sendAuthReq(data->ID, ID);
        validID = false;
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);

    }

    //Ataque
    /*
    if (data->ID == "[99]")
    {
        Qk++; // Packet out
        EV << "Nodo " << ID << " actualiza los valores de Qk: " << Qk << " y Qj: " << Qj << " para el nodo " << data->ID << endl;
    } else
    */
    if (data->ID == "[100]") {
        bubble("Recibida ASO!");
        EV << "RECIBIDO MSG_ASO con ID: " << data->ID << endl;
        EV << "Enviando hash para PoW: " << actualPassHash << "\nhacia el nodo " << data->ID << "; desde el nodo " << ID << endl;
        sendAuthReq(data->ID, ID);
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
    }

    //SEECR out
    SEECR(data->ID, 1, msg);

    currentRx += sx1272_rx;
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(data->ID, ID);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    delete data;
    delete msg;
}

void HonestModule::caseASORESP(cMessage* msg)
{
    auto data = (dataAuthReq*) msg->getContextPointer();
    if (ID == data->IDRx)
    {
        bubble("Recibida ASO_RESP!");
        EV << "El nodo " << ID << " ha recibido el hash enviado por el nodo " << data->IDTx << endl;
        powHash(data->hash, data->IDTx, data->IDRx);
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);

        //latency
        timeFin = simTime();
        timeLatency = timeFin - timeIni;
        EV << "** Latencia: " << timeLatency << " s" << endl;
    }
    currentRx += sx1272_rx;
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(data->IDTx, data->IDRx);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    //Ataque
    /*
    if (data->IDRx == "[99]")
    {
        Qj++; // Packet in
        EV << "Nodo " << ID << " actualiza los valores de Qk: " << Qk << " y Qj: " << Qj << " para el nodo " << data->IDRx << endl;
        //EV << "Qk: " << Qk << " Qj: " << Qj << endl;
    }
    */

    //SEECR in
    SEECR(data->IDRx, 0, msg);

    delete data;
}

void HonestModule::caseAUTH(cMessage* msg)
{
    auto data = (dataAuth*) msg->getContextPointer();
    if (ID == data->IDRx)
    {
        bubble("Recibida AUTH!");
        EV << "RECIBIDO MSG_AUTH con ID: " << data->IDTx << endl;
        EV << "HASH: " << data->hash << endl;
        EV << "actualHash: " << actualSaltHash << " pastHash: " << pastSaltHash << endl;
        if (data->hash == actualSaltHash || data->hash == pastSaltHash){
        //if (data->IDTx != "[99]"){
            EV << "El nodo ha recibido el hash y lo valida!" << endl;
            sendAuthAck(data->IDTx, ID);
            peso++;
            EV << "Peso del nodo " << ID << " es de: " << peso << endl;
            tangleTableInd.push_back(data->IDTx);

            auto copyData = new dataUpdateAso;
            copyData->ID = data->IDTx;
            copyData->IDmaster = ID;

            spreadAso(msg->getSenderModule(), copyData);
            currentTx += sx1272_tx;
            currentTxVector.recordWithTimestamp(simTime(), currentTx);
        } else {
            EV << "El nodo ha recibido el hash y NO lo valida!" << endl;
        }

    }
    currentRx += sx1272_rx;
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(data->IDTx, data->IDRx);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    // Ataque
    /*
    if (data->IDTx == "[99]")
    {
        Qk++; // Packet out
        if (Qk - Qj >= X)
        {
            //EV << "Qk: " << Qk << " Qj: " << Qj << endl;
            EV << "Nodo " << ID << " actualiza los valores de Qk: " << Qk << " y Qj: " << Qj << " para el nodo " << data->IDTx << endl;
            EV << "El nodo " << data->IDTx << " ha sido marcado como atacante!" << endl;

            //Agrega a su propia lista de marcados
            if (std::find(attackerNodes.begin(), attackerNodes.end(), ID + "[99]") != attackerNodes.end())
            {
                EV << "Nodo atacante ya registrado!" << endl;
            } else {
                attackerNodes.push_back(ID + "[99]");
            }

            EV << "Enviando la ID del nodo marcado a todos los nodos..." << endl;
            auto copyData = new dataAttacker;
            copyData->IDattacker = "[99]"; //Nodo atacante
            copyData->ID = ID; //Nodo que lo marca

            spreadAttacker(msg->getSenderModule(), copyData, 1);

            EV << "Aislando al nodo marcado!" << endl;
            isolateAttacker();
        }
    }
     */

    //SEECR out
    SEECR(data->IDTx, 1, msg);

    delete data;
    delete msg;
}

void HonestModule::caseASOACK(cMessage* msg){

    auto data = (dataAuthAck*) msg->getContextPointer();

    if(ID == data->ID)
    {
        EV << "RECIBIDO MSG_ASO_ACK para ID: " << data->ID << endl;
        bubble("Recibida ASO_ACK!");
        EV << "Nodo asociado correctamente!"<< endl;
        //nodo1Aso = true; //flag que indica que nodo 1 esta asociado
    }

    // ISLA 1
    if (ID == "[2]" && !nodo1Aso)
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[3]" && data->ID == "[2]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[4]" && data->ID == "[3]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[5]" && data->ID == "[6]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[6]" && data->ID == "[4]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[7]" && data->ID == "[6]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[8]" && data->ID == "[5]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[9]" && data->ID == "[7]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[40]" && data->ID == "[9]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[41]" && data->ID == "[40]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[42]" && data->ID == "[41]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[43]" && data->ID == "[42]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[44]" && data->ID == "[43]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[45]" && data->ID == "[44]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[46]" && data->ID == "[45]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[47]" && data->ID == "[46]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[48]" && data->ID == "[47]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[49]" && data->ID == "[48]")
    {
        nodo1Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }


    // ISLA 2
    if (ID == "[12]" && !nodo11Aso)
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[13]" && data->ID == "[12]")
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[14]" && data->ID == "[13]")
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[15]" && data->ID == "[16]")
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[16]" && data->ID == "[14]")
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[17]" && data->ID == "[16]")
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[18]" && data->ID == "[15]")
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[19]" && data->ID == "[17]")
    {
        nodo11Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }


    // ISLA 3
    if (ID == "[22]" && !nodo21Aso)
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[23]" && data->ID == "[22]")
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[24]" && data->ID == "[23]")
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[25]" && data->ID == "[26]")
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[26]" && data->ID == "[24]")
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[27]" && data->ID == "[26]")
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[28]" && data->ID == "[25]")
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[29]" && data->ID == "[27]")
    {
        nodo21Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }

    // ISLA 4
    if (ID == "[32]" && !nodo31Aso)
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[33]" && data->ID == "[32]")
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[34]" && data->ID == "[33]")
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[35]" && data->ID == "[36]")
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[36]" && data->ID == "[34]")
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[37]" && data->ID == "[36]")
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[38]" && data->ID == "[35]")
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }
    if (ID == "[39]" && data->ID == "[37]")
    {
        nodo31Aso = true; //flag que indica que nodo 1 esta asociado
        scheduleAt(simTime() + exponential(rateMean), msgBLOQ11);
    }

    currentRx += sx1272_rx;
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(data->ID, data->IDmaster);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    //Energia
    currentTotal = currentTx + currentRx;
    if (ID == "[0]" || ID == "[10]" || ID == "[20]" || ID == "[30]") EV << "*Corriente consumida por la BSTA: " << ID << " es de: " << currentTotal << "mA" << endl;
    else EV << "*Corriente consumida por el nodo: " << ID << " es de: " << currentTotal << "mA" << endl;

    delete data;
    delete msg;
}

void HonestModule::caseUPDATEASO(cMessage* msg){

    auto data =  (dataUpdateAso*) msg->getContextPointer();

    //if (std::find(tangleTableB.begin(), tangleTableB.end(), data->ID) != tangleTableB.end() && std::find(tangleTableA.begin(), tangleTableA.end(), data->IDmaster) != tangleTableA.end())
    if (std::find(tangleTable.begin(), tangleTable.end(), data->IDmaster + data->ID) != tangleTable.end())
    {
        if (ID == "[0]" || ID == "[10]" || ID == "[20]" || ID == "[30]") EV << "El nodo " << data->ID << " asociado por la BSTA " << data->IDmaster << " ya ha sido registrado!\n";
        else EV << "El nodo " << data->ID << " asociado por " << data->IDmaster << " ya se registro!\n";

        delete data;
        delete msg;
        return;
    }

    EV << "Registrando nodo asociado " << data->ID << "\n";

    bubble("Nuevo nodo asociado!");

    tangleTable.push_back(data->IDmaster + data->ID);

    // Actualizar Peso

    for (auto nodeID : tangleTableInd)
    {
        if (nodeID == data->IDmaster)
        {
            peso++;
            tangleTableInd.push_back(data->ID);
        }
    }
    if (ID == "[0]" || ID == "[10]" || ID == "[20]" || ID == "[30]") EV << "Peso de la BSTA " << ID << " es de: " << peso << endl;
    else EV << "Peso del nodo " << ID << " es de: " << peso << endl;

    auto copyData = new dataUpdateAso;
    copyData->ID = data->ID;
    copyData->IDmaster = data->IDmaster;

    spreadAso(msg->getSenderModule(), copyData);
    currentRx += sx1272_rx;
    currentTx += sx1272_tx;
    currentTxVector.recordWithTimestamp(simTime(), currentTx);
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(data->ID, data->IDmaster);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    if (topology == "ConAtaques" || topology == "SinAtaques") {
        if (data->ID == "[9]" || data->ID == "[19]" || data->ID == "[29]") rescheduleAfter(1.00, msgStartTx);
    } else if (topology == "IslaAumentada") {
        if (data->ID == "[9]" || data->ID == "[19]" || data->ID == "[29]" || data->ID == "[39]") rescheduleAfter(1.00, msgStartTx);
    } else if (topology == "NodosAumentados") {
        if (data->ID == "[49]" || data->ID == "[19]" || data->ID == "[29]" || data->ID == "[39]") rescheduleAfter(1.00, msgStartTx);
    }

    delete data;
    delete copyData;
    delete msg;
}

void HonestModule::caseATTACKER(cMessage* msg){

    auto data =  (dataAttacker*) msg->getContextPointer();

    if (std::find(attackerNodes.begin(), attackerNodes.end(), data->ID + data->IDattacker) != attackerNodes.end())
    {
        EV << "El nodo atacante " << data->IDattacker<< " identificado por " << data->ID << " ya ha sido registrado!\n";
        delete data;
        delete msg;
        return;
    }

    EV << "Registrando nodo atacante " << data->IDattacker << "\n";
    bubble("Nodo atacante registrado!");

    attackerNodes.push_back(data->ID + data->IDattacker);

    auto copyData = new dataAttacker;
    copyData->ID = data->ID;
    copyData->IDattacker = data->IDattacker;

    spreadAttacker(msg->getSenderModule(), copyData, 1);
    currentRx += sx1272_rx;
    currentTx += sx1272_tx;
    currentTxVector.recordWithTimestamp(simTime(), currentTx);
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(data->IDattacker, data->ID);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    delete data;
    delete copyData;
    delete msg;
}

void HonestModule::startTx()
{

    if (ID == "[0]" || ID == "[10]" || ID == "[20]" || ID == "[30]" ) {
        //NADA - los nodos BSTA no tienen "sensores"
    } else {
        if (countSensorTx <= maxSensorTx)
        {
            EV << "El nodo " << ID << " envia los datos de sus sensores hacia la BSTA " << nodoBSTA << "!" << endl;

            auto copyData = new dataSensor;
            copyData->destinoID = nodoBSTA;
            copyData->origenID = ID;
            srand(simTime().raw());
            copyData->sensPH = rand() % 14;
            srand(simTime().raw());
            copyData->sensTEMP = rand() % 74 - 20;

            sendSensorData(copyData);
            currentTx += sx1272_tx;
            currentTxVector.recordWithTimestamp(simTime(), currentTx);
            countSensorTx++;

            delete copyData;

            scheduleAt(simTime() + exponential(rateMean) + 5 , msgStartTx); //Se envian lecturas de sensores cada 5s aprox
        }
    }


}

void HonestModule::caseSensorData(cMessage* msg)
{
    auto data = (dataSensor*) msg->getContextPointer();

    if (data->destinoID != ID)
    {
        EV << "Reenviando a ID DESTINO: " << data->destinoID << endl;
        auto copyData = new dataSensor;
        copyData->destinoID = data->destinoID;
        copyData->origenID = data->origenID;
        copyData->sensPH = data->sensPH;
        copyData->sensTEMP = data->sensTEMP;

        sendSensorData(copyData);
        currentTx += sx1272_tx;
        currentTxVector.recordWithTimestamp(simTime(), currentTx);
        delete copyData;
    } else {
        bubble("Recibida SENSOR_DATA!");
        EV << "Datos de sensores recibidos del nodo " << data->origenID << "\nPH: " << data->sensPH << "\nTEMP: " << data->sensTEMP << endl;
        EV << "ID DESTINO: " << data->destinoID << endl;


        //Adaptado para isla grande
        if (ID == "[0]") {

            if (topology == "SinAtaques" || topology == "UnaIsla"){
                if (countNodeTrans < 9) //Se almacenan los datos que componen una sola transaccion
                {
                    string row = "" + data->origenID + ";" + std::to_string(data->sensPH) + ";" + std::to_string(data->sensTEMP) + "";
                    actualTransaction.push_back(row);

                    //Datos mas legibles para BlockChain
                    string row1 = "NodoOrigen: " + data->origenID + " SensorPH: " + std::to_string(data->sensPH) + " SensorTEMP: " + std::to_string(data->sensTEMP) + ";";
                    actualTransactionData.push_back(row1);
                }
            } else {
                if (countNodeTrans < 19) //Se almacenan los datos que componen una sola transaccion
                {
                    string row = "" + data->origenID + ";" + std::to_string(data->sensPH) + ";" + std::to_string(data->sensTEMP) + "";
                    actualTransaction.push_back(row);

                    //Datos mas legibles para BlockChain
                    string row1 = "NodoOrigen: " + data->origenID + " SensorPH: " + std::to_string(data->sensPH) + " SensorTEMP: " + std::to_string(data->sensTEMP) + ";";
                    actualTransactionData.push_back(row1);
                }
            }

            countNodeTrans++;

            if (topology == "SinAtaques" || topology == "UnaIsla"){
                if (countNodeTrans == 9) //Cantidad de nodos max, sin contar Genesis ni Attacker
                {
                    bubble("Transaccion completa!");
                    storeTransaction(); //Al completar los datos para la transaccion se llama al metodo
                    countSensorTx++;
                    countNodeTrans = 0;
                }
            } else {
                if (countNodeTrans == 19) //Cantidad de nodos max, sin contar Genesis ni Attacker
                {
                    bubble("Transaccion completa!");
                    storeTransaction(); //Al completar los datos para la transaccion se llama al metodo
                    countSensorTx++;
                    countNodeTrans = 0;
                }
            }


        } else { //Islas normales de 9 nodos clientes

            if (countNodeTrans < 9) //Se almacenan los datos que componen una sola transaccion
            {
                string row = "" + data->origenID + ";" + std::to_string(data->sensPH) + ";" + std::to_string(data->sensTEMP) + "";
                actualTransaction.push_back(row);

                //Datos mas legibles para BlockChain
                string row1 = "NodoOrigen: " + data->origenID + " SensorPH: " + std::to_string(data->sensPH) + " SensorTEMP: " + std::to_string(data->sensTEMP) + ";";
                actualTransactionData.push_back(row1);
            }

            countNodeTrans++;
            if (countNodeTrans == 9) //Cantidad de nodos max, sin contar Genesis ni Attacker
            {
                bubble("Transaccion completa!");
                storeTransaction(); //Al completar los datos para la transaccion se llama al metodo
                countSensorTx++;
                countNodeTrans = 0;
            }

        }

    }
    currentRx += sx1272_rx;
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(data->origenID, data->destinoID);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    delete data;
    delete msg;
}

//*************** BLOCKCHAIN *************************
void HonestModule::caseBlockChain(cMessage* msg)
{
    auto msgData = (dataBlock*) msg->getContextPointer();
    blockIndex = msgData->index;
    int competeOrder = 0;

    if (msgData->destinoID == ID && !pruebaIslaCaida)
    {
        bubble("BLOCK recibido!");
        //newBlock(msgData->data, msgData->index, -1, msgData->time);
        EV << "*** ACTUALIZANDO BLOCKCHAIN!" << "ENVIADO POR " << msgData->origenID << "\nMI INDEX " << blockIndex + 1 << endl;
        updateBlock(blockIndex, msgData->nonce, msgData->data, msgData->hash, msgData->time, msgData->prevHash);
        blockIndex++;

        EV << "*Islas sin conexion: " << nIslasSinCon << endl;
        for (int i = 0; i < (bstaLimit - nIslasSinCon); i++) {
            if (msgData->origenID == competeVec[0][i]) {
                competeOrder = i;
                break;
            }
        }

        //EV << "CompeteOrder: " << competeOrder << endl;

        if (competeOrder != (bstaLimit - 1 - nIslasSinCon)) { //variable global que maneje en N� de islas
            //Nada

            if (competeVec[0][competeOrder + 1] == ID) {
                if (ID == "[0]") {
                    callSendBlock(blockIndex, "[10]");
                    callSendBlock(blockIndex, "[20]");
                    if (nIslas > 3) callSendBlock(blockIndex, "[30]");
                } else if (ID == "[10]") {
                    callSendBlock(blockIndex, "[0]");
                    callSendBlock(blockIndex, "[20]");
                    if (nIslas > 3) callSendBlock(blockIndex, "[30]");
                } else if (ID == "[20]") {
                    callSendBlock(blockIndex, "[0]");
                    callSendBlock(blockIndex, "[10]");
                    if (nIslas > 3) callSendBlock(blockIndex, "[30]");
                } else if (ID == "[30]") {
                    callSendBlock(blockIndex, "[0]");
                    callSendBlock(blockIndex, "[10]");
                    callSendBlock(blockIndex, "[20]");
                }
            }
        }

    }

    currentRx += sx1272_rx;
    currentRxVector.recordWithTimestamp(simTime(), currentRx);
    //Calcular rxPower en dBm
    float distancia = calcularDistancia(msgData->origenID, msgData->destinoID);
    float rxPower = calcularRxPower(loraTxPower, loraTxFreq, distancia);
    rxPowerSuma += rxPower;
    numeroRx++;
    EV << "Potencia LORAWAN recibida: " << negrita(std::to_string(rxPower)) << " \x1b[1mdBm\x1b[0m a \x1b[1m\x1b[31m" << distancia << " metros!\x1b[0m" << endl;

    delete msgData;
    delete msg;
}

void HonestModule::caseCompeteBlock(cMessage* msg)
{
    if(ID == "[0]" || ID == "[10]" || ID == "[20]" || ID == "[30]") {

        if (transCounter < txLimite){
            bubble("Inicio proceso de competicion!");
            EV << "** BSTA " << ID << " REALIZA MINADO PARA COMPETIR!" << endl;
            if (ID == "[20]" && simTime() > 35.0 && simTime() < 50) {
                blockIndex++;
            } else if (ID == "[0]" && simTime() > 35.0 && simTime() < 50) {
                if(topology != "UnaIsla") blockIndex += 1;
            } else if (ID == "[10]" && simTime() > 50) {
                blockIndex++;
            } else if (ID == "[0]" && simTime() > 50) {
                blockIndex += 2;
            }
            EV << "*** INDEX " << blockIndex << endl;

            string tempData = getTransactionData(transCounter + 1);

            //string tempData = "datos de " + ID;
            addBlockChain(blockIndex, tempData);
            blockIndex++;
            transCounter++;

            scheduleAt(simTime() + exponential(rateMean) + 10, msgCompeteBlock);
        }

    }
}

void HonestModule::caseDataNonce(cMessage* msg)
{
    auto msgData = (dataNonce*) msg->getContextPointer();
    if(ID == msgData->destinoID && !pruebaIslaCaida) {
        EV << "** NONCE " << msgData->nonce << " recibido de " << msgData->origenID << endl;
        competeVec[0][competeCounter] = msgData->origenID;
        competeVec[1][competeCounter] = std::to_string(msgData->nonce);
        competeCounter++;


        if (competeCounter == bstaLimit) {
            cancelTimeOut = true; // Cancela el timeout
            cancelEvent(msgTimeOut);
            EV << "*Cancelando timeOut... en BSTA " << ID << ", ninguna isla deshabilitada!" << endl;
            for(int i = 0; i < bstaLimit; i++){ //Algoritmo de ordenamiento
                for(int j = 0; j < bstaLimit; j++){
                    if (std::stoi(competeVec[1][i]) >= std::stoi(competeVec[1][j])) {
                        //nada
                    } else {
                        string temp1 = competeVec[1][i];
                        string temp2 = competeVec[0][i];
                        competeVec[1][i] = competeVec[1][j];
                        competeVec[0][i] = competeVec[0][j];
                        competeVec[1][j] = temp1;
                        competeVec[0][j] = temp2;
                    }
                }
            }

            //Imprime de el vector de competencia
            EV << "**COMPETEVEC\n";
            for (int k = 0; k < bstaLimit; k++) {
                EV << competeVec[0][k] << " ";
            }
            EV << "\n";
            for (int l = 0; l < bstaLimit; l++) {
                EV << competeVec[1][l] << " ";
            }
            EV << "\n";

            //EV << "**COMPETEVEC\n" << competeVec[0][0] << " " << competeVec[0][1] << " " << competeVec[0][2] << "\n" << competeVec[1][0] << " " <<competeVec[1][1] << " " <<competeVec[1][2] << endl;
            if (competeVec[0][0] == ID) {
                EV << "*** PRIMER BSTA GANADOR " << ID << "\nEnviando con index: " << blockIndex - 1 << "\ncompeteVec[0][0]: " << competeVec[0][0]  << endl;
                if (ID == "[0]") {
                    callSendBlock(blockIndex - 1, "[10]");
                    callSendBlock(blockIndex - 1, "[20]");
                    if (nIslas > 3) callSendBlock(blockIndex - 1, "[30]");
                } else if (ID == "[10]") {
                    callSendBlock(blockIndex - 1, "[0]");
                    callSendBlock(blockIndex - 1, "[20]");
                    if (nIslas > 3) callSendBlock(blockIndex - 1, "[30]");
                } else if (ID == "[20]") {
                    callSendBlock(blockIndex - 1, "[0]");
                    callSendBlock(blockIndex - 1, "[10]");
                    if (nIslas > 3) callSendBlock(blockIndex - 1, "[30]");
                } else if (ID == "[30]") {
                    callSendBlock(blockIndex - 1, "[0]");
                    callSendBlock(blockIndex - 1, "[10]");
                    callSendBlock(blockIndex - 1, "[20]");
                }
            }

            competeCounter = 0;
        } else {
            //Timer para verificar si alguna de las islas no se encuentra disponible
            EV << "*Programando timeOut... BSTA " << ID << endl;
            if (oneScheduleTO == false) scheduleAt(simTime() + 1.00, msgTimeOut);
            else rescheduleAfter(1.00, msgTimeOut);

            oneScheduleTO = true;
        }
    }

    delete msgData;
}


// Metodo que se despliega en caso de que alguna de las islas no pueda hacer el proceso de BLOCKCHAIN
void HonestModule::caseTimeOut() {
    if (!cancelTimeOut) {
        EV << "*Llamando timeOut..." << endl;
        cancelTimeOut = true; // Cancela el timeout
        nIslasSinCon = nIslas - competeCounter;
        for(int i = 0; i < competeCounter; i++){ //Algoritmo de ordenamiento
            for(int j = 0; j < competeCounter; j++){
                if (std::stoi(competeVec[1][i]) >= std::stoi(competeVec[1][j])) {
                    //nada
                } else {
                    string temp1 = competeVec[1][i];
                    string temp2 = competeVec[0][i];
                    competeVec[1][i] = competeVec[1][j];
                    competeVec[0][i] = competeVec[0][j];
                    competeVec[1][j] = temp1;
                    competeVec[0][j] = temp2;
                }
            }
        }

        //Imprime de el vector de competencia
        EV << "**COMPETEVEC\n";
        for (int k = 0; k < competeCounter; k++) {
            EV << competeVec[0][k] << " ";
        }
        EV << "\n";
        for (int l = 0; l < competeCounter; l++) {
            EV << competeVec[1][l] << " ";
        }
        EV << "\n";

        //EV << "**COMPETEVEC\n" << competeVec[0][0] << " " << competeVec[0][1] << " " << competeVec[0][2] << "\n" << competeVec[1][0] << " " <<competeVec[1][1] << " " <<competeVec[1][2] << endl;
        if (competeVec[0][0] == ID && !pruebaIslaCaida) {
            EV << "*** PRIMER BSTA GANADOR " << ID << "\nEnviando con index: " << blockIndex - 1 << "\ncompeteVec[0][0]: " << competeVec[0][0]  << endl;
            if (ID == "[0]") {
                callSendBlock(blockIndex - 1, "[10]");
                callSendBlock(blockIndex - 1, "[20]");
                if (nIslas > 3) callSendBlock(blockIndex - 1, "[30]");
            } else if (ID == "[10]") {
                callSendBlock(blockIndex - 1, "[0]");
                callSendBlock(blockIndex - 1, "[20]");
                if (nIslas > 3) callSendBlock(blockIndex - 1, "[30]");
            } else if (ID == "[20]") {
                callSendBlock(blockIndex - 1, "[0]");
                callSendBlock(blockIndex - 1, "[10]");
                if (nIslas > 3) callSendBlock(blockIndex - 1, "[30]");
            } else if (ID == "[30]") {
                callSendBlock(blockIndex - 1, "[0]");
                callSendBlock(blockIndex - 1, "[10]");
                callSendBlock(blockIndex - 1, "[20]");
            }
        }
        competeCounter = 0;
        oneScheduleTO = false;
        cancelTimeOut = false;
    }
}

void HonestModule::initialize()
{
    _initialize();

    //BSTAlimit
    bstaLimit = nIslas; //Consulta el parametro nBSTAnode del iota.ned

    //******* Prueba de isla caida ***********
    if (ID == "[0]" && islaCaida1) pruebaIslaCaida = true;
    if (ID == "[10]" && islaCaida2) pruebaIslaCaida = true;
    if (ID == "[20]" && islaCaida3) pruebaIslaCaida = true;
    if (ID == "[30]" && islaCaida4) pruebaIslaCaida = true;

    if (topology == "ConAtaques" || topology == "SinAtaques" || topology == "UnaIsla") {

        scheduleAt(simTime() + exponential(rateMean), msgUpdatePass);
        scheduleAt(simTime() + 0.6, msgBLOQ11);
        scheduleAt(simTime() + exponential(rateMean) + 12, msgStartTx); //25
        if (!pruebaIslaCaida) scheduleAt(simTime() + exponential(rateMean) + 15, msgCompeteBlock);

    } else {

        scheduleAt(simTime() + exponential(rateMean), msgUpdatePass);
        scheduleAt(simTime() + exponential(rateMean) + 5.0, msgBLOQ11);
        scheduleAt(simTime() + exponential(rateMean) + 45.0, msgStartTx);
        if (!pruebaIslaCaida) scheduleAt(simTime() + exponential(rateMean) + 50, msgCompeteBlock);
    }

    EV << "\x1b[1mProceso de inicializacion completado!\x1b[0m\n";

}

void HonestModule::handleMessage(cMessage* msg)
{
    EV << "MessageType: " << msg->getKind() << endl;
    //EV << "getDisplayString: " << msg->getDisplayString() << "." << endl;
    switch (msg->getKind())
    {
        case MessageType::ISSUE:
            caseISSUE();
            break;
        case MessageType::POW:
            casePOW(msg);
            break;
        case MessageType::UPDATE:
            caseUPDATE(msg);
            break;
        case MessageType::AUTH:
            caseAUTH(msg);
            break;
        case MessageType::BLOQ11:
            caseBLOQ11();
            break;
        case MessageType::ASO:
            caseASO(msg);
            break;
        case MessageType::ASORESP:
            caseASORESP(msg);
            break;
        case MessageType::ASOACK:
            caseASOACK(msg);
            break;
        case MessageType::UPDATEASO:
            caseUPDATEASO(msg);
            break;
        case MessageType::UPDATEPASS:
            updatePASS();
            break;
        case MessageType::ATTACKER:
            caseATTACKER(msg);
            break;
        case MessageType::STARTTX:
            startTx();
            break;
        case MessageType::SENSORDATA:
            caseSensorData(msg);
            break;
        case MessageType::DATABLOCK:
            caseBlockChain(msg);
            break;
        case MessageType::COMPETE:
            caseCompeteBlock(msg);
            break;
        case MessageType::NONCE:
            caseDataNonce(msg);
            break;
       case MessageType::TIMEOUT:
            caseTimeOut();
            break;
        default:
            break;
    }
}

void HonestModule::refreshDisplay() const
{
    //EV << "Prueba Refresh: " << getDisplayString().str() << endl;
    //getDisplayString().setTagArg("t",0,"Nodo");

    /*
    char buf[128];
    sprintf(buf, "chainheight: %d, coins: %d", chainHeight, coins);
    getDisplayString().setTagArg("t", 0, buf);
    */
}

void HonestModule::printSEECR() {
    std::cout << "*** Mostrando vector SEECR final! para " << ID << " ***" << endl;
    for (int i = 0; i < controlIDvec.size(); i++) {
        std::cout << "Nodo " << controlIDvec[i] << " \x1b[34mQj: " << controlIndVec[i][0] << " \x1b[0m\x1b[31mQk: " << controlIndVec[i][1] << "\x1b[0m" << endl;
    }
}

void HonestModule::finish()
{
    printSEECR();
    _finish(static_cast<bool>(par("exportTangle")),std::make_pair(static_cast<bool>(par("exportTipsNumber")),static_cast<bool>(par("wipeLogTipsNumber"))));
}
