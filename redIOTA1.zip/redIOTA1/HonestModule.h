//includes
#pragma once
#include "AbstractModule.h"
#include <omnetpp.h>
#include <string>
#include <fstream>
#include <map>
#include <iostream>
#include "sha256.h"
#include <string.h>

using std::string;

class HonestModule : public AbstractModule
{
    public:
        //overridden functions from AbstractModule class called in handleMessage() function
        void caseISSUE() override;
        void casePOW(cMessage* msg) override;
        void caseUPDATE(cMessage* msg) override;
        void caseAUTH(cMessage* msg) override;
        void refreshDisplay() const override;
        void powHash(string passHash, string IDRx, string IDTx);
        string checkSalt(string pass, string passHash);
        void caseBLOQ11() override;
        void caseASO(cMessage* msg) override;
        void caseASORESP(cMessage* msg) override;
        void caseASOACK(cMessage* msg) override;
        void caseUPDATEASO(cMessage* msg) override;
        void caseATTACKER(cMessage* msg) override;
        void updatePASS() override;
        void startTx() override;
        void caseSensorData(cMessage* msg) override;
        void caseBlockChain(cMessage* msg) override;
        void caseCompeteBlock(cMessage* msg) override;
        void caseDataNonce(cMessage* msg) override;
        void caseTimeOut();
        void SEECR(string nodoID, int indexIO, cMessage* msg);
        void printSEECR();
        void marcarAtacante(string nodoID, cMessage* msg);

        //overridden functions from cSimpleModule class
        void initialize() override;
        void handleMessage(cMessage * msg) override;
        void finish() override;

        //flags
        bool nodo1Aso = false;
        bool nodo11Aso = false;
        bool nodo21Aso = false;
        bool nodo31Aso = false;
        bool nodoActAso = false;

        //BSTAlimit
        int bstaLimit; //Consulta el parametro nBSTAnode del iota.ned

        bool cancelTimeOut = false;
        bool oneScheduleTO = false;
        int nIslasSinCon = 0;

        //Qk y Qj
        std::vector<std::string> controlIDvec;
        std::vector<std::vector<int> > controlIndVec;


};

Define_Module(HonestModule);
