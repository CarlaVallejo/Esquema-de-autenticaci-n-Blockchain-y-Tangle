//includes 
#pragma once
#include <omnetpp.h>

using namespace omnetpp;
using std::string;

struct Tx;
using VpTx = std::vector<Tx*>;
enum MessageType{ISSUE,POW,UPDATE,ATTACK,PCA,SPA,MB,AUTH,BLOQ11,ASO,ASORESP,ASOACK,UPDATEASO,UPDATEPASS,ATTACKER,STARTTX,SENSORDATA,DATABLOCK,COMPETE,NONCE,TIMEOUT};

//a transaction
struct Tx
{
    Tx(std::string _ID):ID(_ID){}; //constructor

    const std::string ID; //the ID of the transaction
    
    double confidence = 0.0; //confidence (for G-IOTA)
    int countSelected = 0; //how much a tip has been selected during a TSA (for G-IOTA)

    bool isGenesisBlock = false;
    bool isApproved = false; 
    bool isVisited = false; //used during the recursion weight compute process
    
    VpTx approvedBy; //transactions that have approved this transaction directly
    VpTx approvedTx; //transactions approved by this transaction directly

    simtime_t issuedTime; //simulation time when the transaction was issued
    simtime_t approvedTime; //simulation time when this transaction ceased to be a tip (i.e has been approved)

    std::map<std::string,std::pair<bool,bool>> conflictTx; //stores conflicted transaction approved by this transaction
};

//data to send to others modules to update their tangles
struct dataUpdate
{
    std::string ID;  //the ID of the transaction
    std::vector<std::string> approvedTx; //transactions approved by this transaction
};

//struct para la auth
struct dataASO
{
    std::string ID;  //ID del nodo que envia
};

struct dataAuthReq
{
    std::string IDRx;  //ID del nodo destino
    std::string IDTx;  //ID del nodo origen
    std::string hash;  //hash sha-256 diccionario
};

struct dataAuth
{
    std::string IDRx;  //ID del nodo destino
    std::string IDTx;  //ID del nodo origen
    std::string hash;  //hash sha-256 diccionario
};

struct dataAuthAck
{
    std::string ID;  //ID del nodo asociado
    std::string IDmaster;  //ID del nodo que asocia

};

struct dataUpdateAso
{
    std::string ID;  //ID del nodo asociado
    std::string IDmaster;  //ID del nodo que asocia
};

struct dataAttacker
{
    std::string ID;  //ID del nodo que detecto el ataque
    std::string IDattacker;  //ID del nodo marcado como atacante
};

struct dataSensor
{
    string destinoID;  //ID del nodo destino
    string origenID;  //ID del nodo origen
    int sensPH;  //
    int sensTEMP;  //
};

struct dataBlock
{
    int index;
    int nonce;
    string data;
    string hash;
    string prevHash;
    string time;
    string origenID;
    string destinoID;
};

struct dataCompete
{
    std::string temporalData;
};

struct dataNonce
{
    int index;
    int nonce;
    string origenID;
    string destinoID;
};
