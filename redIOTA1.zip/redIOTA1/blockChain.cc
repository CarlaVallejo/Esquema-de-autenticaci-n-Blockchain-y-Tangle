//Blockchain

#include "blockChain.h"




Block::Block(uint32_t nIndexIn, const string &sDataIn) : _nIndex(nIndexIn), _sData(sDataIn) {
    _nNonce = -1;
    _tTime = time(nullptr);
}

string Block::GetHash() {
    return _sHash;
}

void Block::MineBlock(uint32_t nDifficulty) {
    char cstr[nDifficulty + 1];
    for (uint32_t i = 0; i < nDifficulty; ++i) {
        cstr[i] = '0';
    }
    cstr[nDifficulty] = '\0';

    string str(cstr);

    do {
        _nNonce++;
        _sHash = _CalculateHash();
    } while (_sHash.substr(0, nDifficulty) != str);

    //EV << "*****Block mined: " << _sHash << endl;
}

inline string Block::_CalculateHash() const {
    std::stringstream ss;
    ss << _nIndex << _tTime << _sData << _nNonce << sPrevHash;

    return sha256(ss.str());
}



Blockchain::Blockchain() {
    //_vChain.emplace_back(Block(0, "Genesis Block"));
    _vChain.push_back(Block(0, "Genesis Block"));
    _nDifficulty = 2;

    char blockData[4096];
    sprintf(blockData, "{\"index\": %d,\"nonce\": %d, \"data\": %s, \"hash\": %s, \"time\": %s, \"prevHash\": %s}", 0, -1, "Genesis Block", "0", "0", "0");
    stringBlockChain.push_back(blockData);
}

void Blockchain::AddBlock(Block bNew) {
    bNew.sPrevHash = _GetLastBlock().GetHash();
    bNew.MineBlock(_nDifficulty);
    _vChain.push_back(bNew);

    //newBlock(bNew._sData, bNew._sHash, bNew._nNonce, "0");
}

Block Blockchain::_GetLastBlock() const {
    //EV << "lastBlock: " << _vChain.back()._sData << endl;
    return _vChain.back();
}
