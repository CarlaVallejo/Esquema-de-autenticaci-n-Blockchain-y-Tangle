#pragma once
#include <omnetpp.h>
#include <fstream>
#include <ostream>
#include <iostream>
#include <string>

#include <cstdint>
#include <vector>

#include "sha256.h"
#include <sstream>
#include "blockChain.h"

using std::string;
using namespace omnetpp;

class Block {
public:
    string sPrevHash;

    Block(uint32_t nIndexIn, const string &sDataIn);

    string GetHash();

    void MineBlock(uint32_t nDifficulty);

//private:
    uint32_t _nIndex;
    int64_t _nNonce;
    string _sData;
    string _sHash;
    time_t _tTime;

    string _CalculateHash() const;
};

class Blockchain {
public:
    Blockchain();

    void AddBlock(Block bNew);


    //void newBlock(string data, string sHash, int nNonce, string time);

    std::vector<std::string> stringBlockChain;

//private:
    uint32_t _nDifficulty;
    std::vector<Block> _vChain;

    Block _GetLastBlock() const;
};

void MineBlock(uint32_t nDifficulty);
void AddBlock(Block bNew);
